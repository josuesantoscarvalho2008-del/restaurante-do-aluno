const express = require("express");
const http = require("http");
const path = require("path");
const os = require("os");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;
const players = new Map();
const priv = new Map(); // estado interno por jogador (timers etc., não vai para o cliente)
const worldItems = new Map(); // id -> { id, type, x, y, z, ammo? }

// ========== ITENS E ARMAS ==========
// cooldown/reload em segundos; mag 0 = corpo a corpo (sem munição)
const WEAPONS = {
  faca: {
    name: "Faca", color: "#cfd8dc", emoji: "🔪", weapon: true,
    damage: 34, pellets: 1, spread: 0, cooldown: 0.45, mag: 0, reload: 0,
    range: 3.4, auto: false, headshot: 1
  },
  pistola: {
    name: "Pistola", color: "#90a4ae", emoji: "🔫", weapon: true,
    damage: 22, pellets: 1, spread: 0.012, cooldown: 0.28, mag: 12, reload: 1.3,
    range: 120, auto: false, headshot: 2
  },
  espingarda: {
    name: "Espingarda", color: "#ff8c42", emoji: "💥", weapon: true,
    damage: 9, pellets: 8, spread: 0.075, cooldown: 0.9, mag: 6, reload: 2.2,
    range: 45, auto: false, headshot: 1.5
  },
  rifle: {
    name: "Rifle", color: "#54d66f", emoji: "🎯", weapon: true,
    damage: 14, pellets: 1, spread: 0.022, cooldown: 0.1, mag: 30, reload: 2.0,
    range: 150, auto: true, headshot: 1.8
  }
};

const ITEM_TYPES = { ...WEAPONS };

const INVENTORY_SIZE = 5;
const MAX_HP = 100;
const RESPAWN_MS = 3000;
const INVULN_MS = 2500;
let nextItemId = 1;

// ========== MAPA (gerado uma vez; cliente e servidor usam os mesmos dados) ==========
const Terrain = require("./public/terrain.js");

const HALF = 100; // o mapa vai de -HALF a +HALF

function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(20261117);
const rr = (a, b) => a + rand() * (b - a);
const gauss = () => Math.sqrt(-2 * Math.log(rand() + 1e-9)) * Math.cos(2 * Math.PI * rand());

function boxFrom(x, y, z, sx, sy, sz) {
  return { min: [x - sx / 2, y - sy / 2, z - sz / 2], max: [x + sx / 2, y + sy / 2, z + sz / 2] };
}

// x, y, z, sx, sy, sz, cor
const obstacles = [
  [-18, 1.5, -14, 4, 3, 4, 0x8b5a2b],
  [12, 1.5, -10, 5, 3, 3, 0x7c4a21],
  [-8, 1, 16, 3, 2, 6, 0x6d4c41],
  [20, 2, 14, 5, 4, 5, 0x795548],
  [-25, 1.8, 5, 3.5, 3.6, 3.5, 0x8d6e63],
  [5, 1.2, -28, 6, 2.4, 3, 0x5d4037],
  [28, 2.5, -5, 4, 5, 4, 0x6d4c41],
  [-12, 1.5, 28, 4, 3, 4, 0x795548],
  [0, 1, 0, 2, 2, 2, 0x4e342e]
];
const flats = []; // [x, z, raioPlano, raioFim]
obstacles.forEach(([x, , z, sx, , sz]) => {
  const r0 = Math.hypot(sx, sz) / 2 + 1.5;
  flats.push([x, z, r0, r0 + 18]);
});

// Cabanas (paredes com porta, teto escalável)
const cabinSpots = [[-45, 40], [52, -48], [58, 55], [-62, -52]];
cabinSpots.forEach(([cx, cz]) => {
  const wall = 0x8d6e4b, roof = 0x4e3322, H = 3.4, T = 0.5;
  obstacles.push([cx, H / 2, cz - 4, 10, H, T, wall]);              // fundo
  obstacles.push([cx - 5, H / 2, cz, T, H, 8, wall]);               // esquerda
  obstacles.push([cx + 5, H / 2, cz, T, H, 8, wall]);               // direita
  obstacles.push([cx - 3.15, H / 2, cz + 4, 3.7, H, T, wall]);      // frente (esq.)
  obstacles.push([cx + 3.15, H / 2, cz + 4, 3.7, H, T, wall]);      // frente (dir.)
  obstacles.push([cx, H + 0.25, cz, 11, 0.5, 9, roof]); // teto
  obstacles.push([cx - 2, 0.6, cz - 1.5, 1.2, 1.2, 1.2, 0x6d4c41]); // caixa dentro
  flats.push([cx, cz, 9, 28]);
});

// Caixas/muros espalhados pelo mapa maior
const palette = [0x8b5a2b, 0x7c4a21, 0x6d4c41, 0x795548, 0x8d6e63, 0x5d4037];
for (let i = 0, tries = 0; i < 18 && tries < 400; tries++) {
  const x = rr(-68, 68), z = rr(-68, 68);
  if (flats.some(([fx, fz, r0]) => Math.hypot(x - fx, z - fz) < r0 + 16)) continue;
  const sx = rr(2, 4.5), sy = rr(1.5, 3.2), sz = rr(2, 6);
  obstacles.push([x, sy / 2, z, sx, sy, sz, palette[i % palette.length]]);
  const r0 = Math.hypot(sx, sz) / 2 + 1.5;
  flats.push([x, z, r0, r0 + 18]);
  i++;
}

// Colinas
const hills = [];
for (let i = 0; i < 26; i++) {
  hills.push([rr(-HALF, HALF), rr(-HALF, HALF), rr(10, 22), rr(2, 6)]);
}

const terrainParams = { half: HALF, hills, flats };
const heightAt = Terrain.create(terrainParams);
const nearFlat = (x, z, pad, outer) =>
  flats.some(([fx, fz, r0, r1]) => Math.hypot(x - fx, z - fz) < (outer ? r1 : r0) + pad);

// Árvores (carvalho = 0, pinheiro = 1), em florestas
const trees = [];
const forests = Array.from({ length: 12 }, () => [rr(-HALF + 15, HALF - 15), rr(-HALF + 15, HALF - 15)]);
for (let tries = 0; trees.length < 340 && tries < 4000; tries++) {
  let x, z;
  if (rand() < 0.7) {
    const f = forests[Math.floor(rand() * forests.length)];
    x = f[0] + gauss() * 12; z = f[1] + gauss() * 12;
  } else {
    x = rr(-HALF + 4, HALF - 4); z = rr(-HALF + 4, HALF - 4);
  }
  if (Math.abs(x) > HALF - 4 || Math.abs(z) > HALF - 4) continue;
  if (nearFlat(x, z, 7, false)) continue;
  if (trees.some(([tx, tz]) => Math.hypot(x - tx, z - tz) < 2.4)) continue;
  trees.push([Math.round(x * 10) / 10, Math.round(z * 10) / 10, Math.round(rr(0.8, 1.5) * 100) / 100, rand() < 0.55 ? 1 : 0]);
}

// Pedras
const rocks = [];
for (let tries = 0; rocks.length < 70 && tries < 1000; tries++) {
  const x = rr(-HALF + 4, HALF - 4), z = rr(-HALF + 4, HALF - 4);
  if (nearFlat(x, z, 1.5, false)) continue;
  if (trees.some(([tx, tz]) => Math.hypot(x - tx, z - tz) < 2.2)) continue;
  rocks.push([Math.round(x * 10) / 10, Math.round(z * 10) / 10, Math.round(rr(0.7, 2.2) * 100) / 100]);
}

// Sólidos (colisão do jogador e das balas): troncos e pedras, já na altura do terreno
const solids = [];
const canopyBoxes = []; // só bloqueiam balas
trees.forEach(([x, z, s, kind]) => {
  const h = heightAt(x, z);
  solids.push([x, h + 1.2 * s, z, 0.9 * s, 2.4 * s, 0.9 * s]);
  if (kind === 0) canopyBoxes.push(boxFrom(x, h + 3.5 * s, z, 3.2 * s, 3.2 * s, 3.2 * s));
  else canopyBoxes.push(boxFrom(x, h + 4.2 * s, z, 2.6 * s, 5 * s, 2.6 * s));
});
rocks.forEach(([x, z, s]) => {
  solids.push([x, heightAt(x, z) + 0.4 * s, z, 1.7 * s, 1.2 * s, 1.7 * s]);
});

const MAP = { half: HALF, terrain: terrainParams, obstacles, trees, rocks, solids };

// Caixas que bloqueiam balas
const bulletBoxes = [
  ...obstacles.map(([x, y, z, sx, sy, sz]) => boxFrom(x, y, z, sx, sy, sz)),
  ...solids.map(([x, y, z, sx, sy, sz]) => boxFrom(x, y, z, sx, sy, sz)),
  ...canopyBoxes
];

// ========== UTILIDADES ==========
function randomColor() {
  const colors = ["#4da6ff", "#ff5c5c", "#54d66f", "#ffd24d", "#c77dff", "#ff8c42"];
  return colors[Math.floor(Math.random() * colors.length)];
}

function insideSolid(x, z, y, pad) {
  return bulletBoxes.some((b) =>
    x > b.min[0] - pad && x < b.max[0] + pad &&
    z > b.min[2] - pad && z < b.max[2] + pad &&
    b.min[1] < y + 2.2 && b.max[1] > y
  );
}

function spawnPosition() {
  let x = 0, z = 0, y = 0;
  for (let i = 0; i < 40; i++) {
    x = Math.round(rr(-70, 70) * 10) / 10;
    z = Math.round(rr(-70, 70) * 10) / 10;
    y = heightAt(x, z);
    if (!insideSolid(x, z, y, 1.2)) break;
  }
  return { x, y, z };
}

function createStarterInventory() {
  const inv = Array(INVENTORY_SIZE).fill(null);
  inv[0] = { type: "faca" };
  return inv;
}

function clampMap(v) {
  return Math.max(-(HALF - 3), Math.min(HALF - 3, v));
}

function spawnWorldItem(type, x, z, ammo) {
  const id = "item_" + nextItemId++;
  const item = {
    id,
    type,
    x: Math.round(clampMap(x) * 10) / 10,
    y: 0,
    z: Math.round(clampMap(z) * 10) / 10
  };
  item.y = Math.round((heightAt(item.x, item.z) + 0.6) * 100) / 100;
  if (ammo !== undefined) item.ammo = ammo;
  worldItems.set(id, item);
  return item;
}

// Armas espalhadas pelo mapa (e uma dentro de cada cabana)
function seedItems() {
  cabinSpots.forEach(([cx, cz], i) => spawnWorldItem(i % 2 ? "rifle" : "espingarda", cx + 1.5, cz + 1));

  const types = ["pistola", "pistola", "espingarda", "rifle"];
  for (let i = 0, tries = 0; i < 24 && tries < 500; tries++) {
    const x = rr(-HALF + 12, HALF - 12);
    const z = rr(-HALF + 12, HALF - 12);
    if (insideSolid(x, z, heightAt(x, z), 1.5)) continue;
    spawnWorldItem(types[i % types.length], x, z);
    i++;
  }
}

seedItems();

function equippedType(p) {
  const s = p.inventory[p.selected];
  return s && WEAPONS[s.type] && !p.dead ? s.type : null;
}

function updateWeapon(p) {
  const t = equippedType(p);
  if (p.weapon !== t) {
    p.weapon = t;
    io.emit("playerWeapon", { id: p.id, weapon: t });
  }
}

function broadcastScores() {
  const list = [...players.values()]
    .map((p) => ({ id: p.id, name: p.name, kills: p.kills, deaths: p.deaths }))
    .sort((a, b) => b.kills - a.kills || a.deaths - b.deaths);
  io.emit("scores", list);
}

// Solta tudo (menos a faca inicial) ao redor do jogador
function dropAll(p) {
  p.inventory.forEach((slot, i) => {
    if (!slot || slot.type === "faca") return;
    const a = Math.random() * Math.PI * 2;
    const r = 0.8 + Math.random() * 1.2;
    const item = spawnWorldItem(slot.type, p.position.x + Math.cos(a) * r, p.position.z + Math.sin(a) * r, slot.ammo);
    io.emit("itemSpawned", item);
  });
}

// ========== RAIOS (balas) ==========
function rayBox(o, d, min, max) {
  let tmin = 0;
  let tmax = Infinity;
  for (let i = 0; i < 3; i++) {
    if (Math.abs(d[i]) < 1e-9) {
      if (o[i] < min[i] || o[i] > max[i]) return null;
    } else {
      let t1 = (min[i] - o[i]) / d[i];
      let t2 = (max[i] - o[i]) / d[i];
      if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
      if (t1 > tmin) tmin = t1;
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return null;
    }
  }
  return tmin; // 0 = origem dentro da caixa
}

function castRay(o, d, maxRange, shooterId) {
  let best = { t: maxRange, kind: 0 }; // kind: 0 nada, 1 cenário, 2 jogador

  // Terreno: caminha ao longo do raio e refina o ponto de impacto
  let prev = 0;
  for (let t = 1; t <= best.t; t += 1) {
    const y = o[1] + d[1] * t;
    if (y < heightAt(o[0] + d[0] * t, o[2] + d[2] * t)) {
      let lo = prev, hi = t;
      for (let k = 0; k < 8; k++) {
        const m = (lo + hi) / 2;
        if (o[1] + d[1] * m < heightAt(o[0] + d[0] * m, o[2] + d[2] * m)) hi = m; else lo = m;
      }
      if (hi < best.t) best = { t: hi, kind: 1 };
      break;
    }
    prev = t;
    if (y > 40 && d[1] >= 0) break;
  }

  for (const b of bulletBoxes) {
    const t = rayBox(o, d, b.min, b.max);
    if (t !== null && t > 0 && t < best.t) best = { t, kind: 1 };
  }

  for (const [id, pl] of players) {
    if (id === shooterId || pl.dead) continue;
    const min = [pl.position.x - 0.5, pl.position.y, pl.position.z - 0.4];
    const max = [pl.position.x + 0.5, pl.position.y + 2.2, pl.position.z + 0.4];
    const t = rayBox(o, d, min, max);
    if (t !== null && t < best.t) {
      const hy = o[1] + d[1] * t;
      best = { t, kind: 2, victim: pl, head: hy >= pl.position.y + 1.62 };
    }
  }

  return best;
}

function isVec3(v) {
  return Array.isArray(v) && v.length === 3 && v.every((n) => typeof n === "number" && Number.isFinite(n));
}

function normalize(v) {
  const len = Math.hypot(v[0], v[1], v[2]) || 1;
  return [v[0] / len, v[1] / len, v[2] / len];
}

const round2 = (n) => Math.round(n * 100) / 100;

// ========== DANO / MORTE / RESPAWN ==========
function damagePlayer(victim, amount, killer, weaponType) {
  const vs = priv.get(victim.id);
  if (!vs || victim.dead || Date.now() < vs.invulnUntil) return false;

  victim.hp = Math.max(0, victim.hp - Math.round(amount));
  io.to(victim.id).emit("damaged", { hp: victim.hp, from: killer.id });
  io.emit("playerHp", { id: victim.id, hp: victim.hp });

  if (victim.hp <= 0) {
    killPlayer(victim, killer, weaponType);
    return true;
  }
  return false;
}

function cancelReload(st) {
  clearTimeout(st.reloadTimer);
  st.reloadUntil = 0;
}

function killPlayer(victim, killer, weaponType) {
  const vs = priv.get(victim.id);
  victim.dead = true;
  victim.deaths++;
  if (killer && killer.id !== victim.id) killer.kills++;

  cancelReload(vs);
  dropAll(victim);
  victim.inventory = createStarterInventory();
  victim.selected = 0;
  io.to(victim.id).emit("inventoryUpdate", victim.inventory);
  io.to(victim.id).emit("forceSelect", 0);
  updateWeapon(victim);

  io.emit("playerDied", {
    id: victim.id,
    victimName: victim.name,
    killerId: killer ? killer.id : null,
    killerName: killer ? killer.name : "?",
    weapon: weaponType,
    respawnMs: RESPAWN_MS
  });
  broadcastScores();

  clearTimeout(vs.respawnTimer);
  vs.respawnTimer = setTimeout(() => respawnPlayer(victim), RESPAWN_MS);
}

function respawnPlayer(p) {
  const st = priv.get(p.id);
  if (!st || !players.has(p.id)) return;

  p.dead = false;
  p.hp = MAX_HP;
  p.position = spawnPosition();
  p.selected = 0;
  st.invulnUntil = Date.now() + INVULN_MS;

  io.emit("playerRespawned", { id: p.id, position: p.position, hp: p.hp });
  io.emit("playerHp", { id: p.id, hp: p.hp });
  updateWeapon(p);
}

function startReload(p) {
  const st = priv.get(p.id);
  if (!st || p.dead) return;
  const slot = p.inventory[p.selected];
  const w = slot && WEAPONS[slot.type];
  if (!w || !(w.mag > 0) || slot.ammo >= w.mag) return;
  if (st.reloadUntil > Date.now()) return;

  const ms = w.reload * 1000;
  st.reloadUntil = Date.now() + ms;
  io.to(p.id).emit("reloading", ms);

  clearTimeout(st.reloadTimer);
  st.reloadTimer = setTimeout(() => {
    st.reloadUntil = 0;
    if (!p.dead && p.inventory[p.selected] === slot) {
      slot.ammo = w.mag;
      io.to(p.id).emit("inventoryUpdate", p.inventory);
    }
  }, ms);
}

// ========== SERVIDOR ==========
app.use(express.static(path.join(__dirname, "public")));

io.on("connection", (socket) => {
  const player = {
    id: socket.id,
    name: `Jogador ${players.size + 1}`,
    color: randomColor(),
    position: spawnPosition(),
    rotation: 0,
    pitch: 0,
    inventory: createStarterInventory(),
    selected: 0,
    weapon: "faca",
    hp: MAX_HP,
    dead: false,
    kills: 0,
    deaths: 0
  };

  players.set(socket.id, player);
  priv.set(socket.id, {
    nextShot: 0,
    reloadUntil: 0,
    reloadTimer: null,
    respawnTimer: null,
    invulnUntil: Date.now() + INVULN_MS
  });

  socket.emit("welcome", {
    id: socket.id,
    player,
    players: Object.fromEntries(players),
    items: Object.fromEntries(worldItems),
    itemTypes: ITEM_TYPES,
    map: MAP
  });

  socket.broadcast.emit("playerJoined", player);
  broadcastScores();

  socket.on("setName", (name) => {
    const p = players.get(socket.id);
    if (!p) return;
    const clean = String(name || "").trim().slice(0, 16);
    if (clean) p.name = clean;
    io.emit("playerUpdated", p);
    broadcastScores();
  });

  socket.on("move", (data) => {
    const p = players.get(socket.id);
    if (!p || p.dead) return;

    if (
      typeof data?.x !== "number" ||
      typeof data?.y !== "number" ||
      typeof data?.z !== "number" ||
      typeof data?.rotation !== "number"
    ) return;

    p.position.x = Math.max(-(HALF - 2), Math.min(HALF - 2, data.x));
    p.position.y = Math.max(-1, Math.min(45, data.y));
    p.position.z = Math.max(-(HALF - 2), Math.min(HALF - 2, data.z));
    p.rotation = data.rotation;
    if (typeof data.pitch === "number" && Number.isFinite(data.pitch)) {
      p.pitch = Math.max(-1.5, Math.min(1.5, data.pitch));
    }

    socket.broadcast.emit("playerMoved", {
      id: p.id,
      position: p.position,
      rotation: p.rotation,
      pitch: p.pitch
    });
  });

  // Selecionar slot (troca a arma na mão)
  socket.on("select", (idx) => {
    const p = players.get(socket.id);
    const st = priv.get(socket.id);
    if (!p || p.dead) return;
    const i = Number(idx);
    if (!Number.isInteger(i) || i < 0 || i >= INVENTORY_SIZE) return;
    if (i !== p.selected) cancelReload(st);
    p.selected = i;
    updateWeapon(p);
  });

  // Pegar item próximo
  socket.on("pickup", (itemId) => {
    const p = players.get(socket.id);
    const st = priv.get(socket.id);
    const item = worldItems.get(itemId);
    if (!p || !item || p.dead) return;

    const dx = p.position.x - item.x;
    const dz = p.position.z - item.z;
    if (dx * dx + dz * dz > 9) return; // 3 unidades

    const slot = p.inventory.findIndex((s) => s === null);
    if (slot === -1) {
      socket.emit("inventoryFull");
      return;
    }

    const w = WEAPONS[item.type];
    const entry = { type: item.type };
    if (w && w.mag > 0) entry.ammo = item.ammo !== undefined ? item.ammo : w.mag;

    p.inventory[slot] = entry;
    worldItems.delete(itemId);

    io.emit("itemRemoved", itemId);
    socket.emit("inventoryUpdate", p.inventory);

    // Se não tinha arma na mão, equipa a recém-pega
    if (w && !WEAPONS[p.inventory[p.selected]?.type]) {
      cancelReload(st);
      p.selected = slot;
      socket.emit("forceSelect", slot);
    }
    updateWeapon(p);
  });

  // Soltar item do inventário
  socket.on("drop", (slotIndex) => {
    const p = players.get(socket.id);
    const st = priv.get(socket.id);
    if (!p || p.dead) return;

    const idx = Number(slotIndex);
    if (!Number.isInteger(idx) || idx < 0 || idx >= INVENTORY_SIZE) return;
    if (!p.inventory[idx]) return;

    const { type, ammo } = p.inventory[idx];
    p.inventory[idx] = null;
    if (idx === p.selected) cancelReload(st);

    const angle = p.rotation || 0;
    const dropX = p.position.x + Math.sin(angle) * 1.8;
    const dropZ = p.position.z + Math.cos(angle) * 1.8;

    const newItem = spawnWorldItem(type, dropX, dropZ, ammo);
    io.emit("itemSpawned", newItem);
    socket.emit("inventoryUpdate", p.inventory);
    updateWeapon(p);
  });

  // Recarregar
  socket.on("reload", () => {
    const p = players.get(socket.id);
    if (p) startReload(p);
  });

  // Atirar / atacar
  socket.on("shoot", (data) => {
    const p = players.get(socket.id);
    const st = priv.get(socket.id);
    if (!p || p.dead) return;

    const slot = p.inventory[p.selected];
    const w = slot && WEAPONS[slot.type];
    if (!w) return;

    const now = Date.now();
    if (now < st.nextShot || now < st.reloadUntil) return;

    if (!isVec3(data?.origin) || !isVec3(data?.dir)) return;
    const cam = data.origin;
    const dir = normalize(data.dir);

    // A câmera precisa estar perto do jogador
    const eye = [p.position.x, p.position.y + 1.5, p.position.z];
    const toEye = [eye[0] - cam[0], eye[1] - cam[1], eye[2] - cam[2]];
    if (Math.hypot(toEye[0], toEye[1], toEye[2]) > 15) return;

    if (w.mag > 0 && slot.ammo <= 0) {
      socket.emit("emptyClip");
      startReload(p);
      return;
    }

    st.nextShot = now + w.cooldown * 1000 - 40;

    // Origem do tiro: ponto do raio da câmera mais próximo do jogador
    // (evita acertar o que está entre a câmera e o personagem)
    const t0 = Math.max(0, toEye[0] * dir[0] + toEye[1] * dir[1] + toEye[2] * dir[2]);
    const origin = [cam[0] + dir[0] * t0, cam[1] + dir[1] * t0, cam[2] + dir[2] * t0];

    const ends = [];
    const hits = new Map();

    for (let i = 0; i < w.pellets; i++) {
      const s = w.spread;
      const d = normalize([
        dir[0] + (Math.random() * 2 - 1) * s,
        dir[1] + (Math.random() * 2 - 1) * s,
        dir[2] + (Math.random() * 2 - 1) * s
      ]);
      const r = castRay(origin, d, w.range, socket.id);

      ends.push([
        round2(origin[0] + d[0] * r.t),
        round2(origin[1] + d[1] * r.t),
        round2(origin[2] + d[2] * r.t),
        r.kind
      ]);

      if (r.kind === 2) {
        const cur = hits.get(r.victim.id) || { victim: r.victim, amount: 0, head: false };
        cur.amount += w.damage * (r.head ? w.headshot : 1);
        cur.head = cur.head || r.head;
        hits.set(r.victim.id, cur);
      }
    }

    if (w.mag > 0) {
      slot.ammo--;
      socket.emit("inventoryUpdate", p.inventory);
    }

    io.emit("shot", { id: p.id, type: slot.type, ends });

    for (const h of hits.values()) {
      const killed = damagePlayer(h.victim, h.amount, p, slot.type);
      socket.emit("hitConfirm", { kill: killed, head: h.head });
    }

    if (w.mag > 0 && slot.ammo === 0) startReload(p);
  });

  socket.on("disconnect", () => {
    const p = players.get(socket.id);
    const st = priv.get(socket.id);
    if (st) {
      clearTimeout(st.reloadTimer);
      clearTimeout(st.respawnTimer);
    }
    if (p && !p.dead) dropAll(p);
    players.delete(socket.id);
    priv.delete(socket.id);
    io.emit("playerLeft", socket.id);
    broadcastScores();
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`\nJogo iniciado na porta ${PORT}`);
  console.log(`Local: http://localhost:${PORT}`);

  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === "IPv4" && !net.internal) {
        console.log(`LAN:   http://${net.address}:${PORT}`);
      }
    }
  }
});
