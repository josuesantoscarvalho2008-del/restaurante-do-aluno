# Mini 3D LAN

Jogo 3D multiplayer simples para computadores na mesma rede.

## Requisitos

- Node.js instalado
- VS Code (recomendado)
- Computadores conectados à mesma rede Wi-Fi/cabo

## Instalar

Abra o terminal nesta pasta:

```bash
npm install
```

## Iniciar

```bash
npm start
```

O terminal mostrará um endereço LAN, por exemplo:

```text
LAN: http://192.168.1.10:3000
```

No computador que está executando o servidor, abra:

```text
http://localhost:3000
```

Nos outros computadores da mesma rede, abra o endereço LAN mostrado no terminal.

## Controles

- **W A S D** — movimentação
- **Shift** — correr (segure junto com W)
- **Espaço** — pular; aperte de novo no ar para o **pulo duplo** (solte cedo = pulo mais baixo)
- **Clique esquerdo** — atirar / atacar (segure para rifle automático)
- **R** — recarregar
- **E** — pegar item ou arma próxima
- **Q** — soltar item do slot selecionado
- **1 a 5** — selecionar slot do inventário
- **Mouse** — câmera
- **Clique** — capturar o mouse
- **ESC** — liberar o mouse

## Inventário

- Há 5 slots na barra inferior, usados para as armas
- Aproxime-se de uma arma no chão e pressione **E** para pegar
- Pressione **Q** para soltar a arma do slot selecionado
- Clique no slot ou use as teclas 1-5 / scroll para escolher

## Movimentação

- Aceleração e frenagem suaves, com inércia no ar
- Corrida com Shift (o campo de visão abre ao correr)
- Pulo duplo, "coyote time" (pode pular logo após sair de uma borda) e buffer de pulo
- Pernas e braços balançam ao andar; os outros jogadores se movem de forma suave

## Mapa

- Mapa de 200 × 200 com **relevo**: colinas, vales suaves e cordilheira nas bordas
- Terreno colorido por altura e inclinação (grama, terra e pedra), céu em gradiente e neblina
- Florestas de carvalhos e pinheiros, pedras, caixas e **4 cabanas** (com porta e teto escalável)
- Armas espalhadas pelo mapa, inclusive dentro das cabanas
- Árvores, pedras e construções têm colisão e bloqueiam balas; o servidor também calcula tiros contra o relevo

## Armas

Você nasce apenas com a **faca**. As outras armas estão espalhadas pelo mapa: pegue com **E**, equipe selecionando o slot (1-5 ou scroll).

| Arma | Dano | Cadência | Pente | Recarga | Observação |
|------|------|----------|-------|---------|------------|
| 🔪 Faca | 34 | média | ∞ | — | Corpo a corpo (alcance curto) |
| 🔫 Pistola | 22 | média | 12 | 1,3 s | Precisa, semiautomática |
| 💥 Espingarda | 8 × 9 chumbos | lenta | 6 | 2,2 s | Devastadora de perto |
| 🎯 Rifle | 14 | muito rápida | 30 | 2,0 s | Automático (segure o botão) |

- Tiro na **cabeça** causa dano extra.
- Vida máxima: 100. Ao morrer você solta suas armas no chão e renasce em 3 s com proteção temporária.
- O placar (abates/mortes) fica no canto superior direito e o kill feed no esquerdo.
- A munição fica salva na arma: se você a soltar, ela continua com a munição que tinha.
- Balas são bloqueadas por caixas e árvores. Os tiros são validados no servidor.

## Observação

A primeira execução precisa de internet para carregar o Three.js pelo CDN.
