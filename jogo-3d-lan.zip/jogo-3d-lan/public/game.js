import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js";

const socket = io();

const menu = document.getElementById("menu");
const hud = document.getElementById("hud");
const playButton = document.getElementById("play");
const nameInput = document.getElementById("name");
const statusEl = document.getElementById("status");
const countEl = document.getElementById("count");
const pickupHint = document.getElementById("pickup-hint");
const inventoryEl = document.getElementById("inventory");
const hpFill = document.getElementById("hp-fill");
const hpText = document.getElementById("hp-text");
const ammoBox = document.getElementById("ammo");
const weaponNameEl = document.getElementById("weapon-name");
const ammoTextEl = document.getElementById("ammo-text");
const reloadBar = document.getElementById("reload-bar");
const reloadFill = document.getElementById("reload-fill");
const hitmarker = document.getElementById("hitmarker");
const damageFlash = document.getElementById("damage-flash");
const killfeed = document.getElementById("killfeed");
const scoreboard = document.getElementById("scoreboard");
const deathScreen = document.getElementById("death-screen");
const deathInfo = document.getElementById("death-info");

let myId = null;
let started = false;
const remotePlayers = new Map();
const worldItemMeshes = new Map(); // id -> mesh
let inventory = [null, null, null, null, null];
let selectedSlot = 0;
let itemTypes = {};
let nearestItemId = null;
let myHp = 100;
let dead = false;
let mapBuilt = false;

// Combate
let firing = false;
let lastShotAt = 0;
let reloadStart = 0;
let reloadUntil = 0;
let lastClickSound = 0;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87b8e8);
scene.fog = new THREE.Fog(0xc4dcef, 50, 200);

const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  600
);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);

const ambient = new THREE.HemisphereLight(0xffffff, 0x607080, 2);
scene.add(ambient);

const sun = new THREE.DirectionalLight(0xffffff, 3);
sun.position.set(30, 40, 20);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -55;
sun.shadow.camera.right = 55;
sun.shadow.camera.top = 55;
sun.shadow.camera.bottom = -55;
sun.shadow.camera.far = 200;
sun.shadow.bias = -0.0004;
sun.shadow.normalBias = 0.05;
scene.add(sun);
scene.add(sun.target); // a sombra acompanha o jogador

// Céu em gradiente
const sky = new THREE.Mesh(
  new THREE.SphereGeometry(450, 24, 16),
  new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    uniforms: {
      top: { value: new THREE.Color(0x3f86d0) },
      horizon: { value: new THREE.Color(0xc4dcef) }
    },
    vertexShader: "varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",
    fragmentShader: "uniform vec3 top; uniform vec3 horizon; varying vec3 vP; void main(){ float t = clamp(normalize(vP).y, 0.0, 1.0); gl_FragColor = vec4(mix(horizon, top, pow(t, 0.55)), 1.0); }"
  })
);
sky.renderOrder = -1;
scene.add(sky);

// Terreno com relevo (a função de altura vem do servidor via terrain.js)
let heightAt = () => 0;
let BOUND = 97;

// Lista de colisores estáticos (AABB)
const colliders = [];

function addCollider(x, y, z, sx, sy, sz) {
  colliders.push({
    minX: x - sx / 2,
    maxX: x + sx / 2,
    minY: y - sy / 2,
    maxY: y + sy / 2,
    minZ: z - sz / 2,
    maxZ: z + sz / 2
  });
}

function addBox(x, y, z, sx, sy, sz, color) {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(sx, sy, sz),
    new THREE.MeshStandardMaterial({ color })
  );
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  scene.add(mesh);
  addCollider(x, y, z, sx, sy, sz);
  return mesh;
}

function addTree(x, z) {
  const trunk = new THREE.Mesh(
    new THREE.CylinderGeometry(0.35, 0.5, 2.2, 8),
    new THREE.MeshStandardMaterial({ color: 0x6d4c41 })
  );
  trunk.position.set(x, 1.1, z);
  trunk.castShadow = true;
  scene.add(trunk);

  const leaves = new THREE.Mesh(
    new THREE.SphereGeometry(1.8, 10, 10),
    new THREE.MeshStandardMaterial({ color: 0x2e7d32 })
  );
  leaves.position.set(x, 3.2, z);
  leaves.castShadow = true;
  scene.add(leaves);

  addCollider(x, 1.1, z, 1.0, 2.2, 1.0);
}

function pseudo(i) {
  const v = Math.sin(i * 12.9898 + 78.233) * 43758.5453;
  return v - Math.floor(v);
}

function buildTerrain(map) {
  const size = map.half * 2 + 80;
  const seg = Math.round(size / 1.25);
  const geo = new THREE.PlaneGeometry(size, size, seg, seg);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    pos.setY(i, heightAt(pos.getX(i), pos.getZ(i)));
  }
  geo.computeVertexNormals();

  // Cores por altura, inclinação e variação (grama, terra, pedra)
  const nrm = geo.attributes.normal;
  const colors = new Float32Array(pos.count * 3);
  const grassA = new THREE.Color(0x2f6b34);
  const grassB = new THREE.Color(0x6aa044);
  const dirt = new THREE.Color(0x7a6548);
  const rock = new THREE.Color(0x8b8a84);
  const tmp = new THREE.Color();
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    const n = 0.5 + 0.25 * Math.sin(x * 0.31 + z * 0.17) + 0.25 * Math.sin(x * 0.11 - z * 0.37);
    tmp.copy(grassA).lerp(grassB, Math.max(0, Math.min(1, n)));
    const slope = 1 - nrm.getY(i);
    if (slope > 0.12) tmp.lerp(dirt, Math.min(1, (slope - 0.12) * 5));
    if (y > 6.5 || slope > 0.38) tmp.lerp(rock, Math.min(1, Math.max((y - 6.5) / 4, (slope - 0.38) * 4)));
    colors[i * 3] = tmp.r;
    colors[i * 3 + 1] = tmp.g;
    colors[i * 3 + 2] = tmp.b;
  }
  geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));

  const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, metalness: 0 }));
  mesh.receiveShadow = true;
  scene.add(mesh);
}

function buildTrees(trees) {
  if (!trees.length) return;
  const dummy = new THREE.Object3D();
  const col = new THREE.Color();

  const trunkGeo = new THREE.CylinderGeometry(0.28, 0.45, 2.4, 7);
  trunkGeo.translate(0, 1.2, 0);
  const oakGeo = new THREE.IcosahedronGeometry(1.9, 1);
  oakGeo.translate(0, 3.5, 0);
  const pineGeos = [
    new THREE.ConeGeometry(1.7, 2.6, 8).translate(0, 3.0, 0),
    new THREE.ConeGeometry(1.25, 2.3, 8).translate(0, 4.5, 0),
    new THREE.ConeGeometry(0.8, 1.9, 8).translate(0, 5.8, 0)
  ];

  const oaks = trees.filter((t) => t[3] === 0);
  const pines = trees.filter((t) => t[3] === 1);
  const mk = (geo, color, n) => {
    const m = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9, flatShading: true }), n);
    m.castShadow = true;
    m.receiveShadow = true;
    m.userData.base = color;
    scene.add(m);
    return m;
  };

  const trunks = mk(trunkGeo, 0x6d4c41, trees.length);
  const oakMesh = mk(oakGeo, 0x3d8a3a, oaks.length);
  const pineMeshes = pineGeos.map((gm) => mk(gm, 0x1f5e3a, pines.length));

  const place = (mesh, i, t, base, vary) => {
    const [x, z, s] = t;
    dummy.position.set(x, heightAt(x, z), z);
    dummy.scale.setScalar(s);
    dummy.rotation.y = pseudo(x * 7 + z) * 6.28;
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
    col.setHex(base);
    col.offsetHSL((pseudo(i + x) - 0.5) * vary, 0, (pseudo(i * 3 + z) - 0.5) * 0.08);
    mesh.setColorAt(i, col);
  };

  trees.forEach((t, i) => place(trunks, i, t, 0x6d4c41, 0.03));
  oaks.forEach((t, i) => place(oakMesh, i, t, 0x3d8a3a, 0.08));
  pines.forEach((t, i) => pineMeshes.forEach((pm) => place(pm, i, t, 0x1f5e3a, 0.06)));
}

function buildRocks(rocks) {
  if (!rocks.length) return;
  const dummy = new THREE.Object3D();
  const col = new THREE.Color();
  const mesh = new THREE.InstancedMesh(
    new THREE.IcosahedronGeometry(1, 0),
    new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, flatShading: true }),
    rocks.length
  );
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  rocks.forEach(([x, z, s], i) => {
    dummy.position.set(x, heightAt(x, z) + 0.35 * s, z);
    dummy.scale.set(s * 1.0, s * 0.7, s * 0.9);
    dummy.rotation.set(0, pseudo(x + z * 3) * 6.28, 0);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
    col.setHex(0x8a8a85).offsetHSL(0, 0, (pseudo(i * 5 + x) - 0.5) * 0.14);
    mesh.setColorAt(i, col);
  });
  scene.add(mesh);
}

// O mapa vem do servidor (o servidor usa os mesmos dados para as balas)
function buildMap(map) {
  if (mapBuilt || !map) return;
  mapBuilt = true;

  heightAt = window.Terrain.create(map.terrain);
  BOUND = map.half - 3;

  buildTerrain(map);
  map.obstacles.forEach(([x, y, z, sx, sy, sz, color]) => addBox(x, y, z, sx, sy, sz, color));
  buildTrees(map.trees);
  buildRocks(map.rocks);
  // troncos e pedras: só colisão (o visual é instanciado acima)
  map.solids.forEach(([x, y, z, sx, sy, sz]) => addCollider(x, y, z, sx, sy, sz));
}

// ========== ARMAS (modelos) ==========
const matDark = new THREE.MeshStandardMaterial({ color: 0x2b2f36, metalness: 0.5, roughness: 0.5 });
const matMetal = new THREE.MeshStandardMaterial({ color: 0x8a949e, metalness: 0.7, roughness: 0.35 });
const matWood = new THREE.MeshStandardMaterial({ color: 0x8b5a2b });
const matBlade = new THREE.MeshStandardMaterial({ color: 0xdfe6ea, metalness: 0.8, roughness: 0.2 });

// Armas apontam para +Z. O Object3D "muzzle" marca a ponta do cano.
function makeWeaponMesh(type) {
  const g = new THREE.Group();
  const part = (sx, sy, sz, x, y, z, mat) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), mat);
    m.position.set(x, y, z);
    m.castShadow = true;
    g.add(m);
  };
  const muzzle = new THREE.Object3D();

  switch (type) {
    case "faca":
      part(0.09, 0.13, 0.3, 0, 0, 0, matDark);
      part(0.05, 0.2, 0.6, 0, 0.03, 0.45, matBlade);
      muzzle.position.set(0, 0, 0.8);
      break;
    case "pistola":
      part(0.12, 0.17, 0.55, 0, 0, 0.25, matMetal);
      part(0.12, 0.3, 0.14, 0, -0.2, 0.05, matDark);
      part(0.04, 0.05, 0.05, 0, 0.11, 0.5, matDark);   // mira frontal
      part(0.08, 0.04, 0.22, 0, -0.11, 0.2, matDark);  // guarda-mato
      muzzle.position.set(0, 0, 0.55);
      break;
    case "espingarda":
      part(0.11, 0.11, 1.1, 0, 0.02, 0.5, matMetal);
      part(0.16, 0.14, 0.35, 0, -0.06, 0.4, matWood);
      part(0.14, 0.2, 0.5, 0, -0.02, -0.2, matWood);
      muzzle.position.set(0, 0.02, 1.05);
      break;
    case "rifle":
      part(0.14, 0.2, 0.9, 0, 0, 0.35, matDark);
      part(0.07, 0.07, 0.5, 0, 0.02, 0.95, matMetal);
      part(0.1, 0.3, 0.14, 0, -0.22, 0.3, matDark);
      part(0.12, 0.22, 0.4, 0, -0.03, -0.25, matDark);
      part(0.07, 0.07, 0.38, 0, 0.18, 0.35, matDark);   // luneta
      part(0.12, 0.13, 0.42, 0, -0.01, 0.78, matDark);  // protetor de mão
      muzzle.position.set(0, 0.02, 1.2);
      break;
    default:
      part(0.2, 0.2, 0.4, 0, 0, 0.2, matDark);
      muzzle.position.set(0, 0, 0.4);
  }

  g.add(muzzle);
  g.userData.muzzle = muzzle;
  return g;
}

function disposeGeometries(obj) {
  obj.traverse((c) => {
    if (c.isMesh && c.geometry) c.geometry.dispose();
  });
}

// ========== ÍCONES DAS ARMAS (SVG) ==========
const WEAPON_SVG = {
  faca: `
    <rect x="3" y="13" width="20" height="7" rx="3" fill="#6b4a2b"/>
    <circle cx="9" cy="16.5" r="1.2" fill="#d5dde3"/><circle cx="16" cy="16.5" r="1.2" fill="#d5dde3"/>
    <rect x="22" y="9" width="4" height="15" rx="1.5" fill="#8a96a1"/>
    <path d="M26 11 H48 Q58 12 61 17 Q50 21 26 21 Z" fill="#eef3f6"/>
    <path d="M28 18.5 Q48 19.5 60 17.4" stroke="#9aa7b1" stroke-width="1" fill="none"/>`,
  pistola: `
    <path d="M13 19 H31 L27 31 H17 Z" fill="#4a3a2c"/>
    <rect x="12" y="15" width="40" height="5" fill="#8a96a1"/>
    <path d="M12 7 H55 Q58 7 58 10 V16 H12 Z" fill="#d5dde3"/>
    <path d="M16 8 V15 M19 8 V15 M22 8 V15" stroke="#8a96a1" stroke-width="1"/>
    <rect x="57" y="10" width="4" height="4" fill="#3b444c"/>
    <rect x="53" y="4.5" width="3" height="3" fill="#d5dde3"/><rect x="13" y="4.5" width="4" height="3" fill="#d5dde3"/>
    <path d="M33 20 V23 Q33 26 30 26 H25" stroke="#8a96a1" stroke-width="2" fill="none"/>
    <rect x="28" y="20" width="2" height="4" fill="#3b444c"/>`,
  espingarda: `
    <path d="M2 11 L14 9 V20 L5 26 Q2 25 2 22 Z" fill="#c08a4e"/>
    <rect x="14" y="8" width="15" height="11" rx="1.5" fill="#8a96a1"/>
    <rect x="29" y="9" width="34" height="4" fill="#d5dde3"/>
    <rect x="29" y="14" width="29" height="3" fill="#a9b4bd"/>
    <rect x="34" y="13" width="15" height="8" rx="2" fill="#c08a4e"/>
    <path d="M36 15 V19 M39 15 V19 M42 15 V19 M45 15 V19" stroke="#8d5f2c" stroke-width="1"/>
    <path d="M18 19 H25 L23 29 H16 Z" fill="#6b4a2b"/>
    <circle cx="62" cy="7.6" r="1.3" fill="#d5dde3"/>`,
  rifle: `
    <path d="M2 10 L17 11 V19 L6 24 Q2 23 2 20 Z" fill="#4a4f57"/>
    <rect x="17" y="10" width="26" height="9" rx="1.5" fill="#6d7882"/>
    <rect x="43" y="11" width="14" height="7" rx="1.5" fill="#3d434a"/>
    <path d="M46 12 V17 M49 12 V17 M52 12 V17" stroke="#6d7882" stroke-width="1"/>
    <rect x="57" y="12.5" width="6" height="3" fill="#d5dde3"/>
    <rect x="22" y="3" width="17" height="5" rx="2.2" fill="#2f353b"/><rect x="26" y="7.5" width="2.5" height="3" fill="#2f353b"/><rect x="33" y="7.5" width="2.5" height="3" fill="#2f353b"/>
    <path d="M30 19 H39 L37 31 H28 Z" fill="#8a96a1"/>
    <path d="M20 19 H26 L24 28 H18 Z" fill="#3d434a"/>`
};

function weaponIcon(type) {
  const body = WEAPON_SVG[type];
  return body ? `<svg class="wicon" viewBox="0 0 64 32" xmlns="http://www.w3.org/2000/svg">${body}</svg>` : "";
}

// ========== ITENS DO MUNDO ==========
function createItemMesh(data) {
  const typeInfo = itemTypes[data.type] || { color: "#ffffff", emoji: "?" };
  const color = new THREE.Color(typeInfo.color);

  const group = new THREE.Group();
  group.position.set(data.x, data.y, data.z);
  group.userData.itemId = data.id;
  group.userData.baseY = data.y;
  group.userData.itemType = data.type;

  if (typeInfo.weapon) {
    // Arma no chão: modelo da arma, centralizado
    const gun = makeWeaponMesh(data.type);
    const center = new THREE.Box3().setFromObject(gun).getCenter(new THREE.Vector3());
    gun.position.sub(center);
    gun.scale.setScalar(1.5);
    const holder = new THREE.Group();
    holder.add(gun);
    group.add(holder);
  } else {
    // Cubo brilhante
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.55, 0.55, 0.55),
      new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: 0.35,
        metalness: 0.3,
        roughness: 0.4
      })
    );
    mesh.castShadow = true;
    group.add(mesh);
  }

  // Anel embaixo
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.4, 0.55, 16),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.5, side: THREE.DoubleSide })
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = -0.35;
  group.add(ring);

  scene.add(group);
  worldItemMeshes.set(data.id, group);
  return group;
}

function removeItemMesh(id) {
  const mesh = worldItemMeshes.get(id);
  if (mesh) {
    scene.remove(mesh);
    worldItemMeshes.delete(id);
  }
}

// ========== PERSONAGEM ==========
function createPlayer(data, isLocal = false) {
  const color = data.color || 0x4da6ff;
  const group = new THREE.Group();
  group.position.set(data.position.x, data.position.y, data.position.z);
  group.userData.playerId = data.id;

  const bodyMat = new THREE.MeshStandardMaterial({ color });
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.3, 0.55), bodyMat);
  body.position.y = 0.95;
  body.castShadow = true;
  group.add(body);

  const head = new THREE.Mesh(
    new THREE.BoxGeometry(0.55, 0.55, 0.55),
    new THREE.MeshStandardMaterial({ color: 0xffdbac })
  );
  head.position.y = 1.9;
  head.castShadow = true;
  group.add(head);

  const eyeMat = new THREE.MeshStandardMaterial({ color: 0x222222 });
  const eyeL = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.08), eyeMat);
  eyeL.position.set(-0.14, 1.95, 0.28);
  group.add(eyeL);
  const eyeR = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.08), eyeMat);
  eyeR.position.set(0.14, 1.95, 0.28);
  group.add(eyeR);

  const armMat = new THREE.MeshStandardMaterial({ color });
  const legMat = new THREE.MeshStandardMaterial({ color: 0x333333 });

  // Membros com pivô na articulação (ombro/quadril) para poder balançar
  const limb = (sx, sy, sz, px, py, pz, mat) => {
    const pivot = new THREE.Group();
    pivot.position.set(px, py, pz);
    const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), mat);
    m.position.y = -sy / 2;
    m.castShadow = true;
    pivot.add(m);
    group.add(pivot);
    return pivot;
  };

  // Braço direito do personagem (lado -X do modelo): segura a arma
  const armHand = limb(0.28, 0.9, 0.28, -0.65, 1.45, 0, armMat);
  const armOther = limb(0.28, 0.9, 0.28, 0.65, 1.45, 0, armMat);
  const legL = limb(0.32, 0.7, 0.35, -0.25, 0.7, 0, legMat);
  const legR = limb(0.32, 0.7, 0.35, 0.25, 0.7, 0, legMat);

  // Pivô da arma: gira com o pitch (olhar para cima/baixo)
  const weaponPivot = new THREE.Group();
  weaponPivot.position.set(-0.65, 1.4, 0.1);
  const aimArm = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.26, 0.7), armMat);
  aimArm.position.set(0, 0, 0.3);
  aimArm.castShadow = true;
  weaponPivot.add(aimArm);
  const weaponHolder = new THREE.Group();
  weaponHolder.position.set(0, -0.08, 0.5);
  weaponPivot.add(weaponHolder);
  group.add(weaponPivot);

  group.userData.idleArm = armHand;
  group.userData.armOther = armOther;
  group.userData.legL = legL;
  group.userData.legR = legR;
  group.userData.walkAmp = 0;
  group.userData.walkPhase = 0;
  group.userData.targetPos = group.position.clone();
  group.userData.targetYaw = data.rotation || 0;
  group.rotation.y = data.rotation || 0;
  group.userData.aimArm = aimArm;
  group.userData.weaponPivot = weaponPivot;
  group.userData.weaponHolder = weaponHolder;
  group.userData.weaponMesh = null;
  group.userData.weaponType = null;
  group.userData.recoil = 0;
  group.userData.pitch = 0;

  const label = makeLabel(data.name || "Jogador");
  label.position.y = 2.6;
  group.add(label);

  // Barra de vida (só para os outros jogadores)
  if (!isLocal) {
    const bg = new THREE.Sprite(new THREE.SpriteMaterial({ color: 0x000000, transparent: true, opacity: 0.6, depthTest: false }));
    bg.scale.set(1.2, 0.12, 1);
    bg.position.y = 2.3;
    bg.renderOrder = 10;
    const fg = new THREE.Sprite(new THREE.SpriteMaterial({ color: 0x54d66f, depthTest: false }));
    fg.scale.set(1.12, 0.08, 1);
    fg.position.y = 2.3;
    fg.renderOrder = 11;
    group.add(bg, fg);
    group.userData.hpFg = fg;
    group.userData.hpBg = bg;
  }

  scene.add(group);
  setPlayerWeapon(group, data.weapon || null);
  setRemoteHp(group, data.hp ?? 100);
  if (data.dead) group.visible = false;

  if (!isLocal) {
    remotePlayers.set(data.id, group);
  }

  return group;
}

function setPlayerWeapon(group, type) {
  const u = group.userData;
  if (u.weaponMesh) {
    u.weaponHolder.remove(u.weaponMesh);
    disposeGeometries(u.weaponMesh);
    u.weaponMesh = null;
  }
  u.weaponType = type || null;
  if (type) {
    u.weaponMesh = makeWeaponMesh(type);
    u.weaponHolder.add(u.weaponMesh);
  }
  u.weaponPivot.visible = !!type;
  u.idleArm.visible = !type;
}

function setRemoteHp(group, hp) {
  const fg = group.userData.hpFg;
  if (!fg) return;
  const frac = Math.max(0, Math.min(1, hp / 100));
  fg.scale.x = Math.max(0.001, 1.12 * frac);
  fg.material.color.set(frac < 0.35 ? 0xe74c3c : frac < 0.65 ? 0xffd24d : 0x54d66f);
}

function makeLabel(text) {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 64;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "rgba(0,0,0,.6)";
  ctx.roundRect(4, 8, 248, 48, 10);
  ctx.fill();
  ctx.fillStyle = "white";
  ctx.font = "bold 26px Arial";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, 128, 34);

  const texture = new THREE.CanvasTexture(canvas);
  const material = new THREE.SpriteMaterial({
    map: texture,
    transparent: true,
    depthTest: false
  });
  const sprite = new THREE.Sprite(material);
  sprite.scale.set(2.6, 0.65, 1);
  sprite.renderOrder = 12;
  return sprite;
}

function refreshLabel(group, name) {
  const old = group.children.find((c) => c.isSprite && c.material.map);
  if (old) {
    group.remove(old);
    old.material.map.dispose();
    old.material.dispose();
  }
  const label = makeLabel(name);
  label.position.y = 2.6;
  group.add(label);
}

// ========== ÁUDIO ==========
let audioCtx = null;

function getAudio() {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === "suspended") audioCtx.resume();
    return audioCtx;
  } catch {
    return null;
  }
}

function playNoise(kind, pos) {
  const ctx = getAudio();
  if (!ctx) return;

  const dist = pos ? pos.distanceTo(camera.position) : 0;
  const vol = Math.max(0, 1 - dist / 70) * 0.45;
  if (vol < 0.01) return;

  const cfg = {
    faca:       { dur: 0.14, pow: 1.2, type: "bandpass", freq: 3200 },
    pistola:    { dur: 0.17, pow: 3,   type: "lowpass",  freq: 2200 },
    espingarda: { dur: 0.32, pow: 2.5, type: "lowpass",  freq: 1300 },
    rifle:      { dur: 0.13, pow: 3,   type: "lowpass",  freq: 2800 },
    reload:     { dur: 0.06, pow: 1,   type: "bandpass", freq: 1800 },
    click:      { dur: 0.04, pow: 1,   type: "bandpass", freq: 2500 }
  }[kind] || { dur: 0.1, pow: 2, type: "lowpass", freq: 2000 };

  const len = Math.floor(ctx.sampleRate * cfg.dur);
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) {
    data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, cfg.pow);
  }

  const src = ctx.createBufferSource();
  src.buffer = buf;
  const filter = ctx.createBiquadFilter();
  filter.type = cfg.type;
  filter.frequency.value = cfg.freq;
  const gain = ctx.createGain();
  gain.gain.value = vol;
  src.connect(filter).connect(gain).connect(ctx.destination);
  src.start();
}

// ========== EFEITOS (tracers, impactos, clarão) ==========
const effects = [];
const UP = new THREE.Vector3(0, 1, 0);

function addEffect(mesh, life, onUpdate) {
  scene.add(mesh);
  effects.push({ mesh, life, max: life, onUpdate });
}

function spawnTracer(from, to, color = 0xffe08a) {
  const dir = to.clone().sub(from);
  const len = dir.length();
  if (len < 0.2) return;
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.025, 0.025, len, 5),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9 })
  );
  mesh.position.copy(from).addScaledVector(dir, 0.5);
  mesh.quaternion.setFromUnitVectors(UP, dir.normalize());
  addEffect(mesh, 0.08);
}

function spawnImpact(pos, color) {
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.14, 6, 6),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9 })
  );
  mesh.position.copy(pos);
  addEffect(mesh, 0.25, (m, k) => m.scale.setScalar(1 + (1 - k) * 2));
}

function spawnMuzzleFlash(pos) {
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.2, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0xfff2a8, transparent: true, opacity: 1 })
  );
  mesh.position.copy(pos);
  addEffect(mesh, 0.05);
}

function updateEffects(dt) {
  for (let i = effects.length - 1; i >= 0; i--) {
    const e = effects[i];
    e.life -= dt;
    const k = Math.max(0, e.life / e.max);
    e.mesh.material.opacity = k;
    if (e.onUpdate) e.onUpdate(e.mesh, k);
    if (e.life <= 0) {
      scene.remove(e.mesh);
      e.mesh.geometry.dispose();
      e.mesh.material.dispose();
      effects.splice(i, 1);
    }
  }
}

function getMuzzleWorld(group) {
  const m = group.userData.weaponMesh?.userData.muzzle;
  const v = new THREE.Vector3();
  if (m) {
    m.getWorldPosition(v);
  } else {
    v.set(group.position.x, group.position.y + 1.5, group.position.z);
  }
  return v;
}

// ========== INVENTÁRIO / HUD ==========
function currentWeaponDef() {
  const s = inventory[selectedSlot];
  if (!s) return null;
  const t = itemTypes[s.type];
  return t && t.weapon ? t : null;
}

function updateInventoryUI() {
  const slots = inventoryEl.querySelectorAll(".slot");
  slots.forEach((slotEl, i) => {
    const iconEl = slotEl.querySelector(".icon");
    let cEl = slotEl.querySelector(".count");
    if (!cEl) {
      cEl = document.createElement("span");
      cEl.className = "count";
      slotEl.appendChild(cEl);
    }
    const item = inventory[i];
    if (item && itemTypes[item.type]) {
      iconEl.innerHTML = weaponIcon(item.type);
      cEl.textContent = itemTypes[item.type].mag > 0 ? item.ammo : "";
    } else {
      iconEl.innerHTML = "";
      cEl.textContent = "";
    }
    slotEl.classList.toggle("selected", i === selectedSlot);
  });
  updateAmmoUI();
}

function updateAmmoUI() {
  const w = currentWeaponDef();
  if (!w) {
    ammoBox.classList.add("hidden");
    return;
  }
  ammoBox.classList.remove("hidden");
  const wtype = inventory[selectedSlot].type;
  weaponNameEl.innerHTML = weaponIcon(wtype);
  weaponNameEl.appendChild(document.createTextNode(w.name));
  const slot = inventory[selectedSlot];
  if (w.mag > 0) {
    ammoTextEl.textContent = `${slot.ammo} / ${w.mag}`;
    ammoTextEl.classList.toggle("empty", slot.ammo === 0);
  } else {
    ammoTextEl.textContent = "∞";
    ammoTextEl.classList.remove("empty");
  }
}

function updateHpUI(hp) {
  myHp = hp;
  hpFill.style.width = `${Math.max(0, hp)}%`;
  hpFill.style.background = hp < 35 ? "#e74c3c" : hp < 65 ? "#ffd24d" : "#54d66f";
  hpText.textContent = Math.max(0, Math.round(hp));
}

function selectSlot(index, fromServer = false) {
  if (index < 0 || index > 4) return;
  if (index !== selectedSlot) {
    reloadUntil = 0; // trocar de slot cancela a recarga
    reloadBar.classList.add("hidden");
  }
  selectedSlot = index;
  updateInventoryUI();
  if (!fromServer) socket.emit("select", index);
}

// Clique nos slots
inventoryEl.addEventListener("click", (e) => {
  const slot = e.target.closest(".slot");
  if (!slot) return;
  selectSlot(Number(slot.dataset.slot));
});

function showHitmarker(kill) {
  hitmarker.classList.remove("hidden");
  hitmarker.classList.toggle("kill", !!kill);
  clearTimeout(showHitmarker.t);
  showHitmarker.t = setTimeout(() => hitmarker.classList.add("hidden"), kill ? 350 : 140);
}

function flashDamage() {
  damageFlash.style.transition = "none";
  damageFlash.style.opacity = "1";
  requestAnimationFrame(() => requestAnimationFrame(() => {
    damageFlash.style.transition = "opacity .45s ease-out";
    damageFlash.style.opacity = "0";
  }));
}

function addKillfeed(killer, type, victim) {
  const div = document.createElement("div");
  if (killer) {
    const icon = document.createElement("span");
    icon.innerHTML = weaponIcon(type);
    div.append(document.createTextNode(killer), icon, document.createTextNode(victim));
  } else {
    div.textContent = `${victim} morreu`;
  }
  killfeed.appendChild(div);
  while (killfeed.children.length > 5) killfeed.firstChild.remove();
  setTimeout(() => div.remove(), 5000);
}

function renderScores(list) {
  scoreboard.innerHTML = "";
  const head = document.createElement("div");
  head.className = "row head";
  head.innerHTML = "<span>Jogador</span><span>Abates / Mortes</span>";
  scoreboard.appendChild(head);
  list.forEach((p) => {
    const row = document.createElement("div");
    row.className = "row" + (p.id === myId ? " me" : "");
    const n = document.createElement("span");
    n.textContent = p.name;
    const s = document.createElement("span");
    s.textContent = `${p.kills} / ${p.deaths}`;
    row.append(n, s);
    scoreboard.appendChild(row);
  });
}

// ========== CONTROLES ==========
let localPlayer = null;
const keys = new Set();
let yaw = 0;
let pitch = 0; // positivo = olhando para cima
let velocityY = 0;
let canJump = true;
const GRAVITY = -28;
const JUMP_FORCE = 11.5;
const GROUND_Y = 0;

// Movimento
const WALK_SPEED = 7;
const SPRINT_SPEED = 11;
const GROUND_ACCEL = 60;
const GROUND_FRICTION = 50;
const AIR_ACCEL = 16;
const AIR_FRICTION = 3;
const COYOTE_TIME = 0.12;
const JUMP_BUFFER = 0.12;
const BASE_FOV = 75;
let velX = 0;
let velZ = 0;
let onGround = true;
let coyote = 0;
let jumpBuffer = 0;
let airJumps = 1;
let sprintAmount = 0;

const PITCH_MIN = -1.1;
const PITCH_MAX = 0.55;

function startGame() {
  if (started) return;
  started = true;
  menu.classList.add("hidden");
  hud.classList.remove("hidden");
  getAudio();

  if (document.body.requestPointerLock) {
    renderer.domElement.requestPointerLock();
  }
}

playButton.addEventListener("click", () => {
  socket.emit("setName", nameInput.value || "Jogador");
  startGame();
});

nameInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") playButton.click();
});

const tmpDir = new THREE.Vector3();

function tryShoot() {
  if (!started || dead || !localPlayer) return;
  if (document.pointerLockElement !== renderer.domElement) return;
  const w = currentWeaponDef();
  if (!w) return;

  const now = performance.now();
  if (now < reloadUntil) return;
  if (now - lastShotAt < w.cooldown * 1000) return;

  const slot = inventory[selectedSlot];
  if (w.mag > 0 && slot.ammo <= 0) {
    if (now - lastClickSound > 300) {
      playNoise("click");
      lastClickSound = now;
    }
    socket.emit("reload");
    return;
  }

  lastShotAt = now;
  camera.getWorldDirection(tmpDir);
  socket.emit("shoot", {
    origin: camera.position.toArray(),
    dir: tmpDir.toArray()
  });
}

function tryReload() {
  const w = currentWeaponDef();
  if (!w || !(w.mag > 0) || dead) return;
  socket.emit("reload");
}

window.addEventListener("keydown", (e) => {
  const key = e.key.toLowerCase();
  keys.add(key);

  if (key === " " && !e.repeat) jumpBuffer = JUMP_BUFFER;

  // Selecionar slot 1-5
  if (["1", "2", "3", "4", "5"].includes(e.key)) {
    selectSlot(Number(e.key) - 1);
  }

  if (dead) return;

  // Pegar item (E)
  if (key === "e" && nearestItemId) {
    socket.emit("pickup", nearestItemId);
  }

  // Soltar item (Q)
  if (key === "q") {
    socket.emit("drop", selectedSlot);
  }

  // Recarregar (R)
  if (key === "r") {
    tryReload();
  }
});

window.addEventListener("keyup", (e) => {
  const key = e.key.toLowerCase();
  keys.delete(key);
  // Soltar o pulo cedo = pulo mais baixo
  if (key === " " && velocityY > 3) velocityY *= 0.55;
});

window.addEventListener("blur", () => keys.clear());

// Scroll do mouse troca o slot do inventário
window.addEventListener("wheel", (e) => {
  if (!started) return;
  e.preventDefault();
  if (e.deltaY > 0) {
    selectSlot((selectedSlot + 1) % 5);
  } else if (e.deltaY < 0) {
    selectSlot((selectedSlot + 4) % 5);
  }
}, { passive: false });

document.addEventListener("mousemove", (e) => {
  if (document.pointerLockElement !== renderer.domElement) return;
  yaw -= e.movementX * 0.0025;
  pitch += -e.movementY * 0.0025;
  pitch = Math.max(PITCH_MIN, Math.min(PITCH_MAX, pitch));
});

renderer.domElement.addEventListener("click", () => {
  if (started && document.pointerLockElement !== renderer.domElement) {
    renderer.domElement.requestPointerLock();
  }
});

// Atirar com o botão esquerdo
window.addEventListener("mousedown", (e) => {
  if (e.button !== 0) return;
  if (document.pointerLockElement !== renderer.domElement) return;
  firing = true;
  tryShoot();
});

window.addEventListener("mouseup", (e) => {
  if (e.button === 0) firing = false;
});

document.addEventListener("pointerlockchange", () => {
  if (document.pointerLockElement !== renderer.domElement) firing = false;
});

// ========== SOCKET ==========
socket.on("connect", () => {
  statusEl.textContent = "Conectado";
});

socket.on("disconnect", () => {
  statusEl.textContent = "Desconectado";
});

socket.on("welcome", (data) => {
  myId = data.id;
  itemTypes = data.itemTypes || {};
  buildMap(data.map);
  inventory = data.player.inventory || [null, null, null, null, null];
  selectedSlot = data.player.selected ?? 0;
  updateInventoryUI();
  updateHpUI(data.player.hp ?? 100);

  localPlayer = createPlayer(data.player, true);

  for (const [id, p] of Object.entries(data.players)) {
    if (id !== myId) createPlayer(p);
  }

  // Carrega itens do mundo
  if (data.items) {
    for (const item of Object.values(data.items)) {
      createItemMesh(item);
    }
  }

  updateCount();
});

socket.on("playerJoined", (p) => {
  if (!remotePlayers.has(p.id)) createPlayer(p);
  updateCount();
});

socket.on("playerMoved", (p) => {
  const mesh = remotePlayers.get(p.id);
  if (!mesh) return;
  mesh.userData.targetPos.set(p.position.x, p.position.y, p.position.z);
  mesh.userData.targetYaw = p.rotation;
  mesh.userData.pitch = p.pitch || 0;
});

socket.on("playerUpdated", (p) => {
  const group = p.id === myId ? localPlayer : remotePlayers.get(p.id);
  if (group) refreshLabel(group, p.name);
});

socket.on("playerLeft", (id) => {
  const mesh = remotePlayers.get(id);
  if (mesh) {
    scene.remove(mesh);
    remotePlayers.delete(id);
  }
  updateCount();
});

socket.on("playerWeapon", ({ id, weapon }) => {
  const group = id === myId ? localPlayer : remotePlayers.get(id);
  if (group) setPlayerWeapon(group, weapon);
});

socket.on("playerHp", ({ id, hp }) => {
  if (id === myId) {
    updateHpUI(hp);
  } else {
    const g = remotePlayers.get(id);
    if (g) setRemoteHp(g, hp);
  }
});

socket.on("damaged", () => {
  flashDamage();
});

socket.on("hitConfirm", ({ kill, head }) => {
  showHitmarker(kill);
  if (head && !kill) playNoise("click");
});

socket.on("shot", (s) => {
  const group = s.id === myId ? localPlayer : remotePlayers.get(s.id);
  if (!group) return;

  const def = itemTypes[s.type] || {};
  const muzzle = getMuzzleWorld(group);
  group.userData.recoil = 1;

  if (def.mag > 0) {
    spawnMuzzleFlash(muzzle);
    for (const e of s.ends) {
      spawnTracer(muzzle, new THREE.Vector3(e[0], e[1], e[2]));
    }
  }

  for (const e of s.ends) {
    if (e[3] === 1 && def.mag > 0) spawnImpact(new THREE.Vector3(e[0], e[1], e[2]), 0xffe0a0);
    else if (e[3] === 2) spawnImpact(new THREE.Vector3(e[0], e[1], e[2]), 0xff3b3b);
  }

  playNoise(s.type, muzzle);
});

socket.on("reloading", (ms) => {
  reloadStart = performance.now();
  reloadUntil = reloadStart + ms;
  reloadBar.classList.remove("hidden");
  playNoise("reload");
});

socket.on("emptyClip", () => {
  playNoise("click");
});

socket.on("forceSelect", (slot) => {
  selectSlot(slot, true);
});

socket.on("playerDied", (d) => {
  addKillfeed(d.killerId && d.killerId !== d.id ? d.killerName : null, d.weapon, d.victimName);

  if (d.id === myId) {
    dead = true;
    firing = false;
    if (localPlayer) localPlayer.visible = false;
    deathScreen.classList.remove("hidden");
    reloadBar.classList.add("hidden");
    reloadUntil = 0;

    let left = Math.ceil(d.respawnMs / 1000);
    const tick = () => {
      deathInfo.textContent = `Derrotado por ${d.killerName} — renasce em ${left}s`;
      if (--left >= 0 && dead) setTimeout(tick, 1000);
    };
    tick();
  } else {
    const g = remotePlayers.get(d.id);
    if (g) g.visible = false;
  }
});

socket.on("playerRespawned", ({ id, position, hp }) => {
  if (id === myId) {
    dead = false;
    velocityY = 0;
    velX = 0;
    velZ = 0;
    if (localPlayer) {
      localPlayer.position.set(position.x, position.y, position.z);
      localPlayer.visible = true;
    }
    deathScreen.classList.add("hidden");
    updateHpUI(hp);
  } else {
    const g = remotePlayers.get(id);
    if (g) {
      g.position.set(position.x, position.y, position.z);
      g.userData.targetPos.copy(g.position);
      g.visible = true;
      setRemoteHp(g, hp);
    }
  }
});

socket.on("scores", renderScores);

socket.on("inventoryUpdate", (inv) => {
  inventory = inv;
  updateInventoryUI();
});

socket.on("inventoryFull", () => {
  statusEl.textContent = "Inventário cheio!";
  setTimeout(() => {
    if (statusEl.textContent === "Inventário cheio!") statusEl.textContent = "Conectado";
  }, 2000);
});

socket.on("itemRemoved", (id) => {
  removeItemMesh(id);
  if (nearestItemId === id) {
    nearestItemId = null;
    pickupHint.classList.add("hidden");
  }
});

socket.on("itemSpawned", (item) => {
  createItemMesh(item);
});

function updateCount() {
  countEl.textContent = `Jogadores: ${remotePlayers.size + (localPlayer ? 1 : 0)}`;
}

// ========== FÍSICA / COLISÃO ==========
const clock = new THREE.Clock();
let lastSend = 0;

const PLAYER_HALF_W = 0.45;
const PLAYER_HALF_D = 0.35;
const PLAYER_HEIGHT = 2.2;

function getPlayerAABB(pos) {
  return {
    minX: pos.x - PLAYER_HALF_W,
    maxX: pos.x + PLAYER_HALF_W,
    minY: pos.y,
    maxY: pos.y + PLAYER_HEIGHT,
    minZ: pos.z - PLAYER_HALF_D,
    maxZ: pos.z + PLAYER_HALF_D
  };
}

function aabbOverlap(a, b) {
  return (
    a.minX < b.maxX && a.maxX > b.minX &&
    a.minY < b.maxY && a.maxY > b.minY &&
    a.minZ < b.maxZ && a.maxZ > b.minZ
  );
}

function resolveCollisions(pos) {
  let grounded = pos.y <= heightAt(pos.x, pos.z) + 0.08;

  for (const c of colliders) {
    const player = getPlayerAABB(pos);
    if (!aabbOverlap(player, c)) continue;

    const overlapX = Math.min(player.maxX - c.minX, c.maxX - player.minX);
    const overlapY = Math.min(player.maxY - c.minY, c.maxY - player.minY);
    const overlapZ = Math.min(player.maxZ - c.minZ, c.maxZ - player.minZ);

    if (overlapY <= overlapX && overlapY <= overlapZ) {
      const playerCenterY = (player.minY + player.maxY) / 2;
      const colliderCenterY = (c.minY + c.maxY) / 2;
      if (playerCenterY > colliderCenterY) {
        pos.y = c.maxY;
        velocityY = 0;
        grounded = true;
      } else {
        pos.y = c.minY - PLAYER_HEIGHT;
        velocityY = Math.min(velocityY, 0);
      }
    } else if (overlapX < overlapZ) {
      if (pos.x < (c.minX + c.maxX) / 2) pos.x -= overlapX;
      else pos.x += overlapX;
    } else {
      if (pos.z < (c.minZ + c.maxZ) / 2) pos.z -= overlapZ;
      else pos.z += overlapZ;
    }
  }

  for (const other of remotePlayers.values()) {
    if (!other.visible) continue;
    const otherPos = other.position;
    const player = getPlayerAABB(pos);
    const otherBox = getPlayerAABB(otherPos);
    if (!aabbOverlap(player, otherBox)) continue;

    const dx = pos.x - otherPos.x;
    const dz = pos.z - otherPos.z;
    const dist = Math.sqrt(dx * dx + dz * dz) || 0.001;
    const minDist = PLAYER_HALF_W * 2 + 0.05;

    if (dist < minDist) {
      const push = (minDist - dist) / 2;
      pos.x += (dx / dist) * push;
      pos.z += (dz / dist) * push;
    }
  }

  return grounded;
}

function findNearestItem() {
  if (!localPlayer) return null;
  let nearest = null;
  let nearestDist = 3.0; // raio de pickup

  for (const [id, mesh] of worldItemMeshes) {
    const dx = localPlayer.position.x - mesh.position.x;
    const dz = localPlayer.position.z - mesh.position.z;
    const dist = Math.sqrt(dx * dx + dz * dz);
    if (dist < nearestDist) {
      nearestDist = dist;
      nearest = id;
    }
  }
  return nearest;
}

// Raio contra AABB (usado para a câmera não atravessar obstáculos)
function rayBoxT(o, d, c) {
  const min = [c.minX, c.minY, c.minZ];
  const max = [c.maxX, c.maxY, c.maxZ];
  let tmin = 0;
  let tmax = Infinity;
  for (let i = 0; i < 3; i++) {
    if (Math.abs(d[i]) < 1e-9) {
      if (o[i] < min[i] || o[i] > max[i]) return null;
    } else {
      let t1 = (min[i] - o[i]) / d[i];
      let t2 = (max[i] - o[i]) / d[i];
      if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
      if (t1 > tmin) tmin = t1;
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return null;
    }
  }
  return tmin > 0 ? tmin : null;
}

// Câmera terceira pessoa "sobre o ombro": a mira (centro da tela) segue
// exatamente a direção em que a câmera olha.
const camDir = new THREE.Vector3();
const CAM_DIST = 6;
const SHOULDER = 0.9;

function updateCamera() {
  const cp = Math.cos(pitch);
  camDir.set(Math.sin(yaw) * cp, Math.sin(pitch), Math.cos(yaw) * cp);

  // ombro direito do personagem = (-cos, 0, sin)
  const px = localPlayer.position.x - Math.cos(yaw) * SHOULDER;
  const py = localPlayer.position.y + 2.2;
  const pz = localPlayer.position.z + Math.sin(yaw) * SHOULDER;

  let dist = CAM_DIST;
  const o = [px, py, pz];
  const d = [-camDir.x, -camDir.y, -camDir.z];
  for (const c of colliders) {
    const t = rayBoxT(o, d, c);
    if (t !== null && t < dist) dist = Math.max(0.6, t - 0.25);
  }

  camera.position.set(
    px - camDir.x * dist,
    Math.max(heightAt(px - camDir.x * dist, pz - camDir.z * dist) + 0.4, py - camDir.y * dist),
    pz - camDir.z * dist
  );
  camera.lookAt(
    camera.position.x + camDir.x,
    camera.position.y + camDir.y,
    camera.position.z + camDir.z
  );
}

function updateLocalPlayer(dt) {
  if (!localPlayer) return;

  if (!dead) {
    const forward = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw));
    const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));

    const direction = new THREE.Vector3();

    if (keys.has("w")) direction.add(forward);
    if (keys.has("s")) direction.sub(forward);
    if (keys.has("d")) direction.sub(right);
    if (keys.has("a")) direction.add(right);

    // Correr (Shift) só andando para frente
    const sprinting = keys.has("shift") && keys.has("w") && !keys.has("s");
    const maxSpeed = sprinting ? SPRINT_SPEED : WALK_SPEED;

    // Aceleração / atrito (movimento suave, com inércia no ar)
    if (direction.lengthSq() > 0) {
      direction.normalize();
      const wishX = direction.x * maxSpeed;
      const wishZ = direction.z * maxSpeed;
      const dx = wishX - velX;
      const dz = wishZ - velZ;
      const len = Math.hypot(dx, dz);
      if (len > 0.0001) {
        const step = Math.min(len, (onGround ? GROUND_ACCEL : AIR_ACCEL) * dt);
        velX += (dx / len) * step;
        velZ += (dz / len) * step;
      }
    } else {
      const sp = Math.hypot(velX, velZ);
      if (sp > 0.0001) {
        const drop = (onGround ? GROUND_FRICTION : AIR_FRICTION) * dt;
        const k = Math.max(0, sp - drop) / sp;
        velX *= k;
        velZ *= k;
      }
    }

    localPlayer.position.x += velX * dt;
    localPlayer.position.z += velZ * dt;

    // Gravidade
    velocityY += GRAVITY * dt;
    localPlayer.position.y += velocityY * dt;

    // Chão (terreno): acompanha descidas sem "quicar"
    const gh = heightAt(localPlayer.position.x, localPlayer.position.z);
    if (localPlayer.position.y <= gh || (onGround && velocityY <= 0 && localPlayer.position.y - gh < 0.45)) {
      localPlayer.position.y = gh;
      velocityY = 0;
    }

    const touching = resolveCollisions(localPlayer.position);
    onGround = touching && velocityY <= 0.01;

    // Pulo: coyote time + buffer + pulo duplo
    if (onGround) {
      coyote = COYOTE_TIME;
      airJumps = 1;
    } else {
      coyote -= dt;
    }
    jumpBuffer -= dt;

    if (jumpBuffer > 0) {
      if (coyote > 0) {
        velocityY = JUMP_FORCE;
        coyote = 0;
        jumpBuffer = 0;
        onGround = false;
      } else if (airJumps > 0) {
        velocityY = JUMP_FORCE * 0.92;
        airJumps--;
        jumpBuffer = 0;
      }
    }

    // FOV aumenta ao correr
    const hSpeed = Math.hypot(velX, velZ);
    const targetSprint = sprinting && hSpeed > WALK_SPEED + 0.5 ? 1 : 0;
    sprintAmount += (targetSprint - sprintAmount) * Math.min(1, dt * 8);
    const fov = BASE_FOV + sprintAmount * 9;
    if (Math.abs(camera.fov - fov) > 0.05) {
      camera.fov = fov;
      camera.updateProjectionMatrix();
    }

    localPlayer.position.x = THREE.MathUtils.clamp(localPlayer.position.x, -BOUND, BOUND);
    localPlayer.position.z = THREE.MathUtils.clamp(localPlayer.position.z, -BOUND, BOUND);
    localPlayer.rotation.y = yaw;

    // Item próximo
    nearestItemId = findNearestItem();
    if (nearestItemId) {
      const mesh = worldItemMeshes.get(nearestItemId);
      const info = itemTypes[mesh?.userData.itemType];
      pickupHint.innerHTML = `Pressione <b>E</b> para pegar${info ? " " + info.name : ""}`;
      pickupHint.classList.remove("hidden");
    } else {
      pickupHint.classList.add("hidden");
    }

    // Tiro automático (rifle) enquanto o botão está pressionado
    if (firing) {
      const w = currentWeaponDef();
      if (w && w.auto) tryShoot();
    }

    if (performance.now() - lastSend > 40) {
      socket.emit("move", {
        x: localPlayer.position.x,
        y: localPlayer.position.y,
        z: localPlayer.position.z,
        rotation: localPlayer.rotation.y,
        pitch
      });
      lastSend = performance.now();
    }
  } else {
    pickupHint.classList.add("hidden");
  }

  updateCamera();

  // Barra de recarga
  const now = performance.now();
  if (now < reloadUntil) {
    reloadFill.style.width = `${((now - reloadStart) / (reloadUntil - reloadStart)) * 100}%`;
    ammoTextEl.textContent = "Recarregando...";
  } else if (!reloadBar.classList.contains("hidden")) {
    reloadBar.classList.add("hidden");
    updateAmmoUI();
  }
}

// Mira da arma (pitch), recuo e animação de andar
function updatePlayerPose(group, dt, pitchValue, speed, airborne) {
  const u = group.userData;
  if (!u.weaponPivot) return;

  // Andar: pernas e braços balançam conforme a velocidade
  const targetAmp = airborne ? 0.3 : Math.min(1, speed / 7);
  u.walkAmp += (targetAmp - u.walkAmp) * Math.min(1, dt * 12);
  if (!airborne) u.walkPhase += speed * dt * 1.35;
  const swing = Math.sin(u.walkPhase) * u.walkAmp * 0.9;
  u.legL.rotation.x = airborne ? -0.4 * u.walkAmp : swing;
  u.legR.rotation.x = airborne ? 0.4 * u.walkAmp : -swing;
  u.armOther.rotation.x = -swing * 0.8;
  u.idleArm.rotation.x = swing * 0.8;

  u.weaponPivot.rotation.x = -pitchValue;
  if (u.recoil > 0) u.recoil = Math.max(0, u.recoil - dt * 6);
  const r = u.recoil;
  const melee = u.weaponType === "faca";
  u.weaponHolder.position.z = 0.5 + (melee ? r * 0.5 : -r * 0.18);
  u.weaponHolder.rotation.x = melee ? 0 : -r * 0.25;
}

// Jogadores remotos: interpola posição/rotação para ficar suave
function updateRemote(g, dt) {
  const u = g.userData;
  const px = g.position.x;
  const pz = g.position.z;
  const k = 1 - Math.exp(-18 * dt);
  g.position.lerp(u.targetPos, k);
  let dy = u.targetYaw - g.rotation.y;
  dy = Math.atan2(Math.sin(dy), Math.cos(dy));
  g.rotation.y += dy * k;
  const speed = dt > 0.0001 ? Math.hypot(g.position.x - px, g.position.z - pz) / dt : 0;
  updatePlayerPose(g, dt, u.pitch, speed, g.position.y > heightAt(g.position.x, g.position.z) + 0.15);
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);

  updateLocalPlayer(dt);

  // Itens flutuando e girando
  const t = performance.now() * 0.002;
  for (const mesh of worldItemMeshes.values()) {
    mesh.rotation.y += 0.02;
    mesh.position.y = mesh.userData.baseY - 0.05 + Math.sin(t + mesh.position.x) * 0.12;
  }

  if (localPlayer) updatePlayerPose(localPlayer, dt, pitch, dead ? 0 : Math.hypot(velX, velZ), !onGround);
  for (const g of remotePlayers.values()) updateRemote(g, dt);

  updateEffects(dt);

  sky.position.copy(camera.position);
  if (localPlayer) {
    sun.target.position.copy(localPlayer.position);
    sun.position.set(localPlayer.position.x + 30, localPlayer.position.y + 40, localPlayer.position.z + 20);
  }

  renderer.render(scene, camera);
}

window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

animate();
