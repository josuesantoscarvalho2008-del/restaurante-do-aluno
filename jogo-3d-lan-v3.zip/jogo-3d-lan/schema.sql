-- Banco de contas do Mini 3D LAN
CREATE DATABASE IF NOT EXISTS jogo3d_lan
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE jogo3d_lan;

CREATE TABLE IF NOT EXISTS accounts (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(16) NOT NULL UNIQUE,
  display_name VARCHAR(16) NOT NULL,
  password_salt VARCHAR(64) NOT NULL,
  password_hash VARCHAR(128) NOT NULL,
  char_skin VARCHAR(32) NULL,
  weapon_skin VARCHAR(32) NULL,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
