# Mini 3D LAN (Edição Tática & Battle Royale)

Jogo 3D multiplayer para computadores na mesma rede local (LAN).

## Contas

No menu você pode:
- **Convidado** — joga só com um nome
- **Entrar** — login com usuário e senha
- **Criar conta** — registra no servidor da LAN

As senhas são salvas com hash (scrypt) em `data/users.json` no computador que hospeda o servidor. Skins ficam vinculadas à conta.

## Contas (MySQL)

No menu: Convidado, Entrar ou Criar conta.

1. Configure `config.mysql.json` (host, user, password, database)
2. Opcional: `mysql -u root -p < schema.sql`
3. `npm install` e `npm start`

Se o MySQL nao conectar, usa fallback `data/users.json`.
Senhas com hash scrypt. Skins anime/jogos sao salvas na conta.

## Personagens e skins

O visual dos personagens fica em `public/characters.js`:

- **32 skins de personagem** com o nome e a aparência do original (Naruto com bandana e bigodes, Luffy com chapéu de palha, Kratos com a marca vermelha, Batman com capa, Vader, Homem de Ferro, Steve em blocos, etc.).
- **Rosto corrigido**: olhos, sobrancelhas, nariz e boca ficam colados na superfície da cabeça; capacetes, cabelos e máscaras não atravessam mais o rosto.
- **Armas seguradas de verdade**: os braços usam IK de 2 ossos (ombro + cotovelo) e as mãos agarram o cabo; a mão de apoio segura o guarda-mão. A arma acompanha a mira para cima/baixo.
- **15 skins de arma** com efeitos temáticos (Sabre de Luz, Rasengan, Kamehameha, Mjölnir, Batarang, Repulsor, Haki, Vazio, Gelo, Ouro, Energy Sword, Camuflado, Carbono...).
- A cor do jogador **não repinta mais a skin**; em modos de equipe aparece só uma faixa colorida nos braços e nas costas.

Para criar uma skin nova, adicione uma entrada em `CHARACTER_SKINS` (em `characters.js`), o `id` em `CHAR_SKIN_OK` no `server.js` e a `<option>` em `index.html`.

## Feedback de combate

- **Números de dano** subindo no alvo (amarelo = corpo, laranja = headshot, vermelho = abate) e hitmarker que "pulsa".
- **Sons de acerto** diferentes para corpo, headshot e abate.
- **Impactos**: faíscas e buracos de bala nas paredes (somem em 20s), sangue ao acertar jogadores.
- **Cartuchos** caindo da arma (vermelhos na espingarda) e quicando no chão.
- **Recuo da câmera** por arma (sniper e espingarda chutam mais; mirando reduz 40%).
- **Animações**: arma abaixa ao recarregar, amortecimento ao pousar de um pulo e inimigos caem ao morrer.

## Instalar e Iniciar


```bash
npm install
npm start
```

Abra `http://localhost:3000` no computador servidor e o endereço `LAN` mostrado no terminal nos outros computadores da rede.

## Mapas Disponíveis

Escolha o mapa no menu inicial ou pressione **M** durante a partida para trocar e reiniciar a sala:
- **Floresta (Clássico)** — Colinas, árvores, pedras e cabanas.
- **Cidade (Centro Urbano)** — Avenidas cruzadas, prédios acessíveis, carros e guaritas.
- **Favela (Becos e Lajes)** — Casas de tijolo empilhadas, escadas para subir nas lajes, caixas d'água e vielas estreitas.
- **Dust Arena (Estilo CS)** — Bombsites A e B, Meio com portão duplo, caixas de cobertura e varanda.
- **Tactical Site (Estilo Valorant)** — Pátio central geométrico, caixas de Radianita e ângulos táticos.
- **Nuketown (Clássico CoD)** — Mapa pequeno e fechado da comunidade, casas frente a frente, ônibus e muita cobertura.

## Modos de Jogo

- **Modo Livre (Infinito)** — Partida contínua sem limite de abates.
- **Modo Pontos (Mata-Mata)** — Escolha a meta de kills (ex.: 10, 20, 30...). Quem atingir o total vence a partida com tela de troféu e reinício automático.
- **Só Snipe (Mata-Mata)** — Todos nascem com sniper. Meta de kills como no Mata-Mata. Loot de snipers e kits/coletes no mapa.
- **Equipe x Equipe** — Times Azul vs Vermelho, sem fogo amigo, spawn em lados opostos, placar por equipe. Meta de kills do time para vencer.
- **Battle Royale** — Mapa Bermuda (grande, estilo Free Fire). Caminhão voador, paraquedas (ESPAÇO para pular), zona que encolhe, sem respawn — último vivo vence.

## Armas e Itens

- **Faca, Pistola, Espingarda, Rifle, Sniper**
- **Kit Médico** — cura HP (máx. 3 no inventário de kits)
- **Colete** — adiciona armadura (barra azul acima da vida). O dano consome colete primeiro.

## Controles

No menu inicial, use **CONFIGURAR TECLAS** para remapear as teclas. As escolhas ficam salvas neste navegador.


- **W A S D** — movimentação
- **Ctrl** — agachar (segure)
- **Shift** — correr (segure junto com W)
- **Espaço** — pular (aperte de novo no ar para pulo duplo)
- **Clique esquerdo** — atirar / atacar
- **Clique direito** — mirar (zoom suave sobre o ombro e precisão aumentada; sniper tem zoom maior)
- **R** — recarregar
- **E** — pegar item/arma/colete ou usar kit médico
- **Q** — soltar item
- **M** — abrir opções de mapa e modo de jogo
- **1 a 5 / Scroll** — selecionar slot
