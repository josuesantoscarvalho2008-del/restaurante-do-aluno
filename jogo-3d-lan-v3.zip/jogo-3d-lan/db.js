/**
 * Camada de contas: MySQL (preferencial) com fallback para JSON local.
 * Configure via variáveis de ambiente ou config.mysql.json
 */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DATA_DIR = path.join(__dirname, "data");
const USERS_FILE = path.join(DATA_DIR, "users.json");
const CONFIG_FILE = path.join(__dirname, "config.mysql.json");

let pool = null;
let useMysql = false;

function readMysqlConfig() {
  const cfg = {
    host: process.env.MYSQL_HOST || "127.0.0.1",
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER || "root",
    password: process.env.MYSQL_PASSWORD || "",
    database: process.env.MYSQL_DATABASE || "jogo3d_lan"
  };
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const fileCfg = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8"));
      Object.assign(cfg, fileCfg);
    }
  } catch (_) {}
  return cfg;
}

function ensureJsonStore() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, "{}", "utf8");
}

function loadJsonUsers() {
  ensureJsonStore();
  try {
    return JSON.parse(fs.readFileSync(USERS_FILE, "utf8") || "{}");
  } catch (_) {
    return {};
  }
}

function saveJsonUsers(users) {
  ensureJsonStore();
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), "utf8");
}

async function initDb() {
  ensureJsonStore();
  let mysql;
  try {
    mysql = require("mysql2/promise");
  } catch (err) {
    console.warn("[contas] Pacote mysql2 não encontrado. Usando JSON em data/users.json");
    console.warn("         Rode: npm install mysql2");
    useMysql = false;
    return { mode: "json" };
  }

  const cfg = readMysqlConfig();
  try {
    // Conecta sem database para criar se necessário
    const boot = await mysql.createConnection({
      host: cfg.host,
      port: cfg.port,
      user: cfg.user,
      password: cfg.password,
      multipleStatements: true
    });
    await boot.query(`CREATE DATABASE IF NOT EXISTS \`${cfg.database}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    await boot.end();

    pool = mysql.createPool({
      host: cfg.host,
      port: cfg.port,
      user: cfg.user,
      password: cfg.password,
      database: cfg.database,
      waitForConnections: true,
      connectionLimit: 10,
      namedPlaceholders: true
    });

    await pool.query(`
      CREATE TABLE IF NOT EXISTS accounts (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(16) NOT NULL UNIQUE,
        display_name VARCHAR(16) NOT NULL,
        password_salt VARCHAR(64) NOT NULL,
        password_hash VARCHAR(128) NOT NULL,
        char_skin VARCHAR(32) NULL,
        weapon_skin VARCHAR(32) NULL,
        created_at BIGINT NOT NULL,
        updated_at BIGINT NOT NULL,
        INDEX idx_username (username)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);

    useMysql = true;
    console.log(`[contas] MySQL conectado → ${cfg.user}@${cfg.host}:${cfg.port}/${cfg.database}`);
    return { mode: "mysql", config: cfg };
  } catch (err) {
    console.warn("[contas] Falha ao conectar MySQL:", err.message);
    console.warn("[contas] Fallback automático para data/users.json");
    pool = null;
    useMysql = false;
    return { mode: "json", error: err.message };
  }
}

function hashPassword(password, salt) {
  const s = salt || crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(String(password), s, 32).toString("hex");
  return { salt: s, hash };
}

function verifyPassword(password, salt, hash) {
  try {
    const h = crypto.scryptSync(String(password), salt, 32).toString("hex");
    return crypto.timingSafeEqual(Buffer.from(h, "hex"), Buffer.from(hash, "hex"));
  } catch (_) {
    return false;
  }
}

function rowToUser(row) {
  if (!row) return null;
  return {
    username: row.username,
    displayName: row.display_name || row.displayName || row.username,
    salt: row.password_salt || row.salt,
    hash: row.password_hash || row.hash,
    charSkin: row.char_skin || row.charSkin || null,
    weaponSkin: row.weapon_skin || row.weaponSkin || null,
    createdAt: row.created_at || row.createdAt || Date.now()
  };
}

function publicAccount(user) {
  if (!user) return null;
  return {
    username: user.username,
    displayName: user.displayName,
    charSkin: user.charSkin || null,
    weaponSkin: user.weaponSkin || null,
    createdAt: user.createdAt
  };
}

async function findUser(username) {
  if (useMysql && pool) {
    const [rows] = await pool.query(
      "SELECT * FROM accounts WHERE username = :username LIMIT 1",
      { username }
    );
    return rowToUser(rows[0]);
  }
  const users = loadJsonUsers();
  return users[username] || null;
}

async function createUser({ username, displayName, salt, hash, charSkin, weaponSkin }) {
  const now = Date.now();
  if (useMysql && pool) {
    await pool.query(
      `INSERT INTO accounts
        (username, display_name, password_salt, password_hash, char_skin, weapon_skin, created_at, updated_at)
       VALUES
        (:username, :displayName, :salt, :hash, :charSkin, :weaponSkin, :createdAt, :updatedAt)`,
      {
        username,
        displayName,
        salt,
        hash,
        charSkin: charSkin || null,
        weaponSkin: weaponSkin || null,
        createdAt: now,
        updatedAt: now
      }
    );
    return findUser(username);
  }

  const users = loadJsonUsers();
  if (users[username]) {
    const err = new Error("EXISTS");
    throw err;
  }
  users[username] = {
    username,
    displayName,
    salt,
    hash,
    charSkin: charSkin || null,
    weaponSkin: weaponSkin || null,
    createdAt: now
  };
  saveJsonUsers(users);
  return users[username];
}

async function updateUserSkins(username, { charSkin, weaponSkin }) {
  if (useMysql && pool) {
    const sets = [];
    const params = { username, updatedAt: Date.now() };
    if (charSkin !== undefined) {
      sets.push("char_skin = :charSkin");
      params.charSkin = charSkin;
    }
    if (weaponSkin !== undefined) {
      sets.push("weapon_skin = :weaponSkin");
      params.weaponSkin = weaponSkin;
    }
    if (!sets.length) return findUser(username);
    sets.push("updated_at = :updatedAt");
    await pool.query(
      `UPDATE accounts SET ${sets.join(", ")} WHERE username = :username`,
      params
    );
    return findUser(username);
  }

  const users = loadJsonUsers();
  if (!users[username]) return null;
  if (charSkin !== undefined) users[username].charSkin = charSkin;
  if (weaponSkin !== undefined) users[username].weaponSkin = weaponSkin;
  saveJsonUsers(users);
  return users[username];
}

function isMysql() {
  return useMysql;
}

module.exports = {
  initDb,
  hashPassword,
  verifyPassword,
  publicAccount,
  findUser,
  createUser,
  updateUserSkins,
  isMysql,
  normalizeUsername(name) {
    return String(name || "").trim().toLowerCase().slice(0, 16);
  },
  displayUsername(name) {
    return String(name || "").trim().slice(0, 16);
  }
};
