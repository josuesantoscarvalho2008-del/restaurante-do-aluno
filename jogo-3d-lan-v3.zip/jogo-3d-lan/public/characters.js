import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js";

const DEG = Math.PI / 180;
const hex = (n) => "#" + n.toString(16).padStart(6, "0");

// ========== TEXTURAS PROCEDURAIS ==========
const _tex = new Map();
function canvasTex(key, w, h, draw, { repeat = null, nearest = false } = {}) {
  if (_tex.has(key)) return _tex.get(key);
  if (typeof document === "undefined") return null;
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  draw(c.getContext("2d"), w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) {
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(repeat[0], repeat[1]);
  }
  if (nearest) {
    t.magFilter = THREE.NearestFilter;
    t.minFilter = THREE.NearestFilter;
    t.generateMipmaps = false;
  }
  t.anisotropy = 4;
  _tex.set(key, t);
  return t;
}

function webTex(base) {
  return canvasTex("web" + base, 256, 256, (g, w, h) => {
    g.fillStyle = hex(base);
    g.fillRect(0, 0, w, h);
    g.strokeStyle = "rgba(10,10,10,.85)";
    g.lineWidth = 2;
    for (let i = 0; i <= 8; i++) {
      g.beginPath(); g.moveTo(i * w / 8, 0); g.lineTo(i * w / 8, h); g.stroke();
    }
    for (let j = 0; j <= 6; j++) {
      const y = j * h / 6;
      for (let i = 0; i < 8; i++) {
        g.beginPath();
        g.moveTo(i * w / 8, y);
        g.quadraticCurveTo((i + 0.5) * w / 8, y + h / 16, (i + 1) * w / 8, y);
        g.stroke();
      }
    }
  });
}

function checkerTex(c1, c2) {
  return canvasTex("chk" + c1 + c2, 64, 64, (g, w, h) => {
    g.fillStyle = hex(c1); g.fillRect(0, 0, w, h);
    g.fillStyle = hex(c2);
    for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) if ((x + y) % 2) g.fillRect(x * 16, y * 16, 16, 16);
  }, { repeat: [4, 2] });
}

function camoTex(base, cols, seed = 7) {
  return canvasTex("camo" + base + seed, 128, 128, (g, w, h) => {
    g.fillStyle = hex(base); g.fillRect(0, 0, w, h);
    let s = seed;
    const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
    for (let i = 0; i < 46; i++) {
      g.fillStyle = hex(cols[i % cols.length]);
      g.beginPath();
      g.ellipse(rnd() * w, rnd() * h, 8 + rnd() * 16, 5 + rnd() * 10, rnd() * 3, 0, Math.PI * 2);
      g.fill();
    }
  }, { repeat: [2, 2] });
}

function carbonTex() {
  return canvasTex("carbon", 32, 32, (g) => {
    g.fillStyle = "#111"; g.fillRect(0, 0, 32, 32);
    g.fillStyle = "#2a2d33";
    for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) if ((x + y) % 2) g.fillRect(x * 8, y * 8, 8, 8);
    g.fillStyle = "#3a3e46";
    for (let i = 0; i < 4; i++) g.fillRect(i * 8 + 1, ((i % 2) * 8) + 1, 6, 2);
  }, { repeat: [3, 3] });
}

function steveFaceTex() {
  const pal = { H: "#3b2a17", S: "#c58c5b", W: "#ffffff", B: "#3a3fa0", N: "#a8693f", D: "#6b3f22" };
  const rows = ["HHHHHHHH", "HHHHHHHH", "HSSSSSSH", "WBSSSSBW", "SSSNNSSS", "SSSSSSSS", "SSSDDSSS", "SSSSSSSS"];
  return canvasTex("steveface", 8, 8, (g) => {
    rows.forEach((r, y) => [...r].forEach((c, x) => { g.fillStyle = pal[c]; g.fillRect(x, y, 1, 1); }));
  }, { nearest: true });
}

function logoTex(letter, bg, fg) {
  return canvasTex("logo" + letter + bg + fg, 64, 64, (g) => {
    g.fillStyle = hex(bg); g.beginPath(); g.arc(32, 32, 31, 0, Math.PI * 2); g.fill();
    g.fillStyle = hex(fg); g.font = "bold 44px Arial"; g.textAlign = "center"; g.textBaseline = "middle";
    g.fillText(letter, 32, 35);
  });
}

// ========== SKINS DE PERSONAGEM ==========
// Campos extras: tone (pele), hair {style,color,spikes}, tags (peças), sleeves, legs, boots, gloves, belt, torsoBare, wrist, eye
const SP = (az, pol, len, rad, dir) => ({ az, pol, len, rad, dir });

export const CHARACTER_SKINS = {
  // —— Clássicas ——
  soldado: { name: "Soldado", primary: 0x4b5d3a, secondary: 0x3a4a2d, pants: 0x4a5238, gear: 0x2a2f22, accent: 0xb59b3c,
    tone: 0xd9a066, hair: { style: "short", color: 0x3b2a1f }, boots: 0x1f1f1a, gloves: 0x1f2418, tags: ["helmet", "vest", "pack", "camoPants"] },
  deserto: { name: "Deserto", primary: 0xc2a66a, secondary: 0xa88b4a, pants: 0xa88b4a, gear: 0x5c4a2e, accent: 0xe0c070,
    tone: 0xc68642, hair: { style: "short", color: 0x1a120e }, boots: 0x4a3a22, gloves: 0x5c4a2e, tags: ["shemagh", "goggles", "vest", "pack"] },
  artico: { name: "Ártico", primary: 0xe8edf3, secondary: 0xaeb6c4, pants: 0xaab4c2, gear: 0x4c566a, accent: 0x88c0d0,
    tone: 0xf1c27d, hair: { style: "short", color: 0x6b4423 }, boots: 0x39414f, gloves: 0x39414f, tags: ["furhood", "vest"] },
  neon: { name: "Neon", primary: 0x1a1a2e, secondary: 0x16213e, pants: 0x0f3460, gear: 0x0a0a12, accent: 0x00ffc8,
    tone: 0xe0ac69, hair: { style: "short", color: 0x111111 }, boots: 0x0a0a12, gloves: 0x0a0a12, tags: ["visor", "neonTrim", "helmetSlim"] },
  tatico: { name: "Tático", primary: 0x2b3038, secondary: 0x1e2228, pants: 0x1c2026, gear: 0x0d0f12, accent: 0xff4655,
    tone: 0xe0ac69, hair: { style: "short", color: 0x1a120e }, boots: 0x0d0f12, gloves: 0x0d0f12, tags: ["balaclava", "helmetBlack", "vest", "pack"] },
  urban: { name: "Urbano", primary: 0x5a6270, secondary: 0x454c58, pants: 0x2f3b55, gear: 0x22262e, accent: 0x4da6ff,
    tone: 0xc68642, hair: { style: "short", color: 0x1a120e }, boots: 0xe8e8e8, tags: ["cap", "hoodie"] },

  // —— Anime ——
  naruto: { name: "Naruto", primary: 0xff7a00, secondary: 0xe67700, pants: 0xf06a00, gear: 0x1a1a2e, accent: 0xf5d76e,
    tone: 0xf1c27d, eye: 0x2f6fd6, hair: { style: "spiky", color: 0xffd23f, spikes: [SP(0, 55, .16, .06, .9), SP(35, 62, .2, .07, .8), SP(-35, 62, .2, .07, .8), SP(70, 70, .2, .07, .7), SP(-70, 70, .2, .07, .7), SP(110, 72, .18, .07, .6), SP(-110, 72, .18, .07, .6), SP(160, 62, .2, .07, .6), SP(-160, 62, .2, .07, .6), SP(0, 20, .2, .07, .3)] },
    boots: 0x1b2a49, gloves: null, headband: 0x1b2a6b, tags: ["headband", "whiskers", "narutoJacket"] },
  goku: { name: "Goku", primary: 0xff6a00, secondary: 0xe85d04, pants: 0xff6a00, gear: 0x1d3f9e, accent: 0x4cc9f0,
    tone: 0xf0bf8a, eye: 0x111111, hair: { style: "spiky", color: 0x111111, spikes: [SP(0, 40, .3, .09, .2), SP(40, 45, .34, .09, .3), SP(-40, 45, .34, .09, .3), SP(80, 55, .3, .09, .5), SP(-80, 55, .3, .09, .5), SP(140, 50, .28, .09, .6), SP(-140, 50, .28, .09, .6), SP(180, 40, .3, .09, .5), SP(0, 12, .34, .09, 0)] },
    boots: 0x1d3f9e, gloves: null, belt: 0x1d3f9e, wrist: 0x1d3f9e, sleeves: "short", tags: ["gokuGi", "browStrong"] },
  luffy: { name: "Luffy", primary: 0xd62828, secondary: 0xc1121f, pants: 0x3b6ea5, gear: 0x4a3728, accent: 0xffd166,
    tone: 0xe9b48a, hair: { style: "short", color: 0x0b0b0b }, boots: 0x6b4a2b, belt: 0xf2d03b, sleeves: "none", legs: "shorts", torsoBare: true,
    tags: ["strawhat", "scarLuffy", "openVest", "bigSmile"] },
  sasuke: { name: "Sasuke", primary: 0x1b263b, secondary: 0x0d1b2a, pants: 0xe8e8e8, gear: 0x0a0a0a, accent: 0x7b2cbf,
    tone: 0xf5d5b5, eye: 0x111111, hair: { style: "spiky", color: 0x0a0a14, spikes: [SP(180, 50, .22, .07, .5), SP(150, 62, .2, .07, .4), SP(-150, 62, .2, .07, .4), SP(120, 70, .18, .06, .3), SP(-120, 70, .18, .06, .3), SP(180, 75, .22, .07, .2)] },
    boots: 0x1b263b, gloves: 0x1b263b, belt: 0x7b2cbf, headband: 0x1b2a6b, tags: ["headband", "highCollar", "ropeBelt", "bangs"] },
  vegeta: { name: "Vegeta", primary: 0x1d4e89, secondary: 0x163a66, pants: 0x1d4e89, gear: 0xffffff, accent: 0xffd60a,
    tone: 0xe6b283, eye: 0x111111, hair: { style: "spiky", color: 0x0d0d0d, spikes: [SP(0, 25, .42, .1, 0), SP(30, 35, .4, .09, .05), SP(-30, 35, .4, .09, .05), SP(65, 45, .3, .08, .25), SP(-65, 45, .3, .08, .25), SP(180, 35, .3, .09, .2)] },
    boots: 0xffffff, gloves: 0xffffff, sleeves: "none", tags: ["saiyanArmor", "browStrong"] },
  gojo: { name: "Gojo", primary: 0x111111, secondary: 0x1a1a1a, pants: 0x111111, gear: 0x0a0a0a, accent: 0x4cc9f0,
    tone: 0xf5d9c0, hair: { style: "spiky", color: 0xf2f6ff, spikes: [SP(0, 25, .24, .07, 0), SP(35, 35, .22, .07, .2), SP(-35, 35, .22, .07, .2), SP(70, 48, .2, .07, .4), SP(-70, 48, .2, .07, .4), SP(110, 55, .2, .07, .5), SP(-110, 55, .2, .07, .5), SP(180, 45, .22, .07, .4), SP(150, 50, .2, .07, .4), SP(-150, 50, .2, .07, .4)] },
    boots: 0x111111, gloves: 0x111111, tags: ["blindfold", "highCollar"] },
  tanjiro: { name: "Tanjiro", primary: 0x1b1b1b, secondary: 0x081c15, pants: 0x1b1b1b, gear: 0x2d6a4f, accent: 0xe9c46a,
    tone: 0xe9b48a, eye: 0x8a2b2b, hair: { style: "short", color: 0x4a1c1c }, boots: 0xe8e8e8, gloves: 0xe8e8e8, tags: ["scarForehead", "earrings", "haori"] },

  // —— Jogos ——
  masterchief: { name: "Master Chief", primary: 0x4a7c3f, secondary: 0x2f5233, pants: 0x3d5c34, gear: 0x1b1b1b, accent: 0xd9a521,
    tone: 0xd9a066, boots: 0x3d5c34, gloves: 0x3d5c34, tags: ["spartan", "vest"] },
  kratos: { name: "Kratos", primary: 0x9e9e9e, secondary: 0x7a7a7a, pants: 0x4a3524, gear: 0x4a3524, accent: 0xb00020,
    tone: 0xe9e1da, hair: { style: "bald", color: 0x2a2a2a }, boots: 0x3a2a1c, gloves: null, sleeves: "none", torsoBare: true, wrist: 0x6b6b6b,
    tags: ["kratosFace", "leatherStraps", "loincloth"] },
  link: { name: "Link", primary: 0x2d6a4f, secondary: 0x1b4332, pants: 0xe8e0c8, gear: 0x6b4226, accent: 0xffd166,
    tone: 0xf0c8a0, eye: 0x2f6fd6, hair: { style: "long", color: 0xe7c35a }, boots: 0x6b4226, gloves: 0x6b4226, belt: 0x6b4226, tags: ["linkCap", "pointyEars", "tunic", "swordBack"] },
  mario: { name: "Mario", primary: 0xe63946, secondary: 0xc1121f, pants: 0x1d4fd8, gear: 0x5c4033, accent: 0xffd166,
    tone: 0xf0c8a0, eye: 0x2f6fd6, hair: { style: "short", color: 0x4a2b17 }, boots: 0x5c4033, gloves: 0xffffff, belt: 0x1d4fd8, tags: ["marioCap", "mustache", "bigNose", "overalls"] },
  sonic: { name: "Sonic", primary: 0x1d8fff, secondary: 0x0d6efd, pants: 0x1d8fff, gear: 0xffffff, accent: 0xffd166,
    tone: 0x1d8fff, boots: 0xe63946, gloves: 0xffffff, sleeves: "none", tags: ["sonic"] },
  spider: { name: "Spider", primary: 0xc1121f, secondary: 0x9b0d18, pants: 0x9b0d18, gear: 0x0d1b2a, accent: 0x4cc9f0,
    tone: 0xe0ac69, boots: 0x0d1b2a, gloves: 0x0d1b2a, suit: "web", tags: ["spiderMask", "spiderEmblem"] },
  steve: { name: "Steve", primary: 0x35b5c9, secondary: 0x29b6f6, pants: 0x3a46a8, gear: 0x5d4037, accent: 0xffcc80,
    tone: 0xc58c5b, boots: 0x555555, sleeves: "short", blocky: true, tags: ["steveHead"] },
  ezio: { name: "Ezio", primary: 0xf0f0ea, secondary: 0xe0e0e0, pants: 0xcfc8b8, gear: 0x4a2f1a, accent: 0xc1121f,
    tone: 0xd9a47a, eye: 0x5a3a1a, hair: { style: "short", color: 0x2a1a10 }, boots: 0x4a2f1a, gloves: 0x4a2f1a, belt: 0xc1121f, wrist: 0x4a2f1a, tags: ["assassinHood", "robeSkirt", "stubble", "sashTail"] },
  geralt: { name: "Geralt", primary: 0x1c1c1c, secondary: 0x111111, pants: 0x2a2520, gear: 0x2e2e2e, accent: 0xc9a227,
    tone: 0xe4c3a0, hair: { style: "long", color: 0xe9e9e9 }, boots: 0x1a1612, gloves: 0x1a1612, wrist: 0x2e2e2e, tags: ["catEyes", "scarEye", "stubble", "studStrap", "swordBack"] },
  cloud: { name: "Cloud", primary: 0x2d2f5c, secondary: 0x4a235a, pants: 0x2a2a3c, gear: 0x2c2c54, accent: 0xa0c4ff,
    tone: 0xf0cba8, eye: 0x7fe7ff, hair: { style: "spiky", color: 0xf2d36b, spikes: [SP(0, 30, .3, .1, .3), SP(35, 38, .3, .1, .4), SP(-35, 38, .3, .1, .4), SP(70, 50, .3, .09, .6), SP(-70, 50, .3, .09, .6), SP(110, 58, .3, .09, .7), SP(-110, 58, .3, .09, .7), SP(180, 55, .34, .1, .8), SP(150, 60, .3, .09, .7), SP(-150, 60, .3, .09, .7)] },
    boots: 0x2c2c54, gloves: 0x5a3a1a, sleeves: "none", tags: ["mako", "pauldron", "busterSword"] },
  pika: { name: "Pika", primary: 0xffd60a, secondary: 0xf4c430, pants: 0xffd60a, gear: 0x5a3a1a, accent: 0xd90429,
    tone: 0xffd60a, boots: 0xffd60a, gloves: 0xffd60a, sleeves: "none", tags: ["pikachu"] },

  // —— Filmes ——
  batman: { name: "Batman", primary: 0x3a3f47, secondary: 0x2a2d33, pants: 0x3a3f47, gear: 0x151515, accent: 0xe6b800,
    tone: 0xe0b894, boots: 0x151515, gloves: 0x151515, belt: 0xe6b800, tags: ["cowl", "cape", "batEmblem", "utilityBelt", "gauntlets"] },
  ironman: { name: "Homem de Ferro", primary: 0xb71c1c, secondary: 0x7f0000, pants: 0xb71c1c, gear: 0xc99a2e, accent: 0x7fe7ff,
    tone: 0xd9a066, boots: 0xc99a2e, gloves: 0xc99a2e, metal: true, tags: ["ironHelm", "arcReactor", "ironArmor"] },
  joker: { name: "Coringa", primary: 0x5a1a8a, secondary: 0x4a148c, pants: 0x2a1038, gear: 0x2e7d32, accent: 0x76ff03,
    tone: 0xf0efe8, eye: 0x2a2a2a, hair: { style: "long", color: 0x2e7d32 }, boots: 0x1b1b1b, gloves: 0x6a1b9a, tags: ["jokerFace", "suitJacket", "vestSuit"] },
  matrix: { name: "Matrix", primary: 0x111111, secondary: 0x050505, pants: 0x0b0b0b, gear: 0x1b1b1b, accent: 0x00ff41,
    tone: 0xe0ac69, hair: { style: "short", color: 0x0a0a0a }, boots: 0x050505, gloves: 0x0b0b0b, tags: ["sunglasses", "longCoat"] },
  vader: { name: "Vader", primary: 0x151515, secondary: 0x050505, pants: 0x111111, gear: 0x242424, accent: 0xff3030,
    tone: 0x151515, boots: 0x0b0b0b, gloves: 0x0b0b0b, tags: ["vaderHelm", "vaderCape", "chestPanel"] },
  johnwick: { name: "John Wick", primary: 0x202020, secondary: 0x111111, pants: 0x1a1a1a, gear: 0x2b2b2b, accent: 0xc9a227,
    tone: 0xe0ac69, hair: { style: "slick", color: 0x2a1a10 }, boots: 0x0b0b0b, gloves: 0x111111, tags: ["stubble", "suitShirt", "suitJacket"] },
  deadpool: { name: "Deadpool", primary: 0xb71c1c, secondary: 0x7f0000, pants: 0x1a1a1a, gear: 0x111111, accent: 0x222222,
    tone: 0xb71c1c, boots: 0x111111, gloves: 0x111111, tags: ["deadpoolMask", "katanas", "beltPouches"] },
  spidey: { name: "Homem-Aranha", primary: 0xc1121f, secondary: 0x8b0000, pants: 0x0d47a1, gear: 0x111111, accent: 0x4cc9f0,
    tone: 0xe0ac69, boots: 0xc1121f, gloves: 0xc1121f, suit: "web", tags: ["spiderMask", "spiderEmblem"] }
};
export const CHARACTER_SKIN_IDS = Object.keys(CHARACTER_SKINS);

// ========== CONSTRUÇÃO DO PERSONAGEM ==========
const HX = 0.23, HY = 0.25, HZ = 0.235, HCY = 1.93;
const headZ = (x, y) => {
  const v = 1 - (x / HX) ** 2 - ((y - HCY) / HY) ** 2;
  return v > 0 ? HZ * Math.sqrt(v) : 0;
};
const headR = (y) => HX * Math.sqrt(Math.max(0.05, 1 - ((y - HCY) / HY) ** 2));

export function buildCharacter(skinId, opts = {}) {
  const sk = CHARACTER_SKINS[skinId] || CHARACTER_SKINS.soldado;
  const tags = new Set(sk.tags || []);
  const has = (t) => tags.has(t);
  const blocky = !!sk.blocky;
  const root = new THREE.Group();

  // ----- materiais -----
  const std = (color, o = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.7, metalness: 0.04, ...o });
  const glow = (c, i = 1, o = {}) => std(c, { emissive: c, emissiveIntensity: i, roughness: 0.3, ...o });
  const tone = sk.tone ?? 0xe0ac69;
  const mSkin = std(tone, { roughness: 0.55 });
  const metalOpts = sk.metal ? { roughness: 0.3, metalness: 0.75 } : { roughness: 0.65 };
  const mPri = std(sk.primary, metalOpts);
  const mSec = std(sk.secondary, { roughness: 0.6 });
  const mPants = std(sk.pants, sk.metal ? metalOpts : { roughness: 0.8 });
  const mGear = std(sk.gear, { roughness: sk.metal ? 0.3 : 0.5, metalness: sk.metal ? 0.8 : 0.25 });
  const mAcc = std(sk.accent, { roughness: 0.35, metalness: 0.35, emissive: sk.accent, emissiveIntensity: 0.15 });
  const mHair = std(sk.hair?.color ?? 0x3b2a1f, { roughness: 0.9 });
  const mWhite = std(0xffffff, { roughness: 0.4 });
  const mBlack = std(0x0e0e0e, { roughness: 0.35 });
  const mBoots = std(sk.boots ?? sk.gear, { roughness: 0.55 });
  const mGlove = sk.gloves != null ? std(sk.gloves, { roughness: 0.6 }) : mSkin;
  const mBelt = std(sk.belt ?? sk.gear, { roughness: 0.5, metalness: 0.2 });
  const lipColor = new THREE.Color(tone).multiplyScalar(0.62);
  const mLip = std(lipColor, { roughness: 0.5 });
  if (sk.suit === "web") {
    const a = webTex(sk.primary), b = webTex(sk.pants);
    if (a) { mPri.map = a; mPri.needsUpdate = true; }
    if (b) { mPants.map = b; mPants.needsUpdate = true; }
  }
  if (has("camoPants")) {
    const t = camoTex(sk.pants, [0x3a4a2d, 0x2a2f22, 0x6b6a45]);
    if (t) { mPants.map = t; mPants.needsUpdate = true; }
  }

  // ----- helpers -----
  const put = (m, x, y, z, parent = root) => { m.position.set(x, y, z); m.castShadow = true; parent.add(m); return m; };
  const sph = (r, mat, x, y, z, sx = 1, sy = 1, sz = 1, parent = root) => {
    const m = put(new THREE.Mesh(new THREE.SphereGeometry(r, 16, 12), mat), x, y, z, parent);
    m.scale.set(sx, sy, sz);
    return m;
  };
  const box = (w, h, d, mat, x, y, z, parent = root) => put(new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat), x, y, z, parent);
  const cyl = (rt, rb, h, mat, x, y, z, parent = root, seg = 16, open = false, th0 = 0, thL = Math.PI * 2) => {
    const m = put(new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg, 1, open, th0, thL), mat), x, y, z, parent);
    if (open) m.material = mat.clone(), m.material.side = THREE.DoubleSide;
    return m;
  };
  const cone = (r, h, mat, x, y, z, parent = root, seg = 8) => put(new THREE.Mesh(new THREE.ConeGeometry(r, h, seg), mat), x, y, z, parent);
  const tube = (rt, rb, h, mat, x, y, z, parent) =>
    blocky
      ? box((rt + rb) * 1.05, h, (rt + rb) * 1.05, mat, x, y, z, parent)
      : cyl(rt, rb, h, mat, x, y, z, parent, 14);
  const rot = (m, x = 0, y = 0, z = 0) => { m.rotation.set(x, y, z); return m; };

  // casca esférica ajustada à cabeça (sem z-fighting)
  const shell = (thStart, thLen, grow, mat, phiStart = 0, phiLen = Math.PI * 2) => {
    const g = new THREE.SphereGeometry(1, 28, 18, phiStart, phiLen, thStart, thLen);
    const m = new THREE.Mesh(g, mat);
    m.scale.set(HX + grow, HY + grow, HZ + grow);
    m.position.set(0, HCY, 0);
    m.castShadow = true;
    root.add(m);
    return m;
  };
  // faixa ao redor da cabeça
  const band = (y, h, grow, mat) => {
    const r = headR(y);
    const m = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, h, 28, 1, true), mat);
    m.material = mat.clone(); m.material.side = THREE.DoubleSide;
    m.scale.set(r + grow, 1, (r + grow) * (HZ / HX));
    m.position.set(0, y, 0);
    root.add(m);
    return m;
  };
  const ring = (y, tubeR, mat, grow = 0) => {
    const m = new THREE.Mesh(new THREE.TorusGeometry(headR(y) + grow + tubeR * 0.5, tubeR, 8, 28), mat);
    m.rotation.x = Math.PI / 2;
    m.scale.set(1, (HZ / HX), 1);
    m.position.set(0, y, 0);
    m.castShadow = true;
    root.add(m);
    return m;
  };
  // curva colada na superfície do rosto
  const decal = (pts, tubeR, mat) => {
    const v = pts.map(([x, y]) => new THREE.Vector3(x, y, headZ(x, y) + tubeR * 0.5));
    const m = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(v), 24, tubeR, 6, false), mat);
    root.add(m);
    return m;
  };
  const onFace = (m, x, y, off = 0) => { m.position.set(x, y, headZ(x, y) + off); return m; };
  const spike = (s, mat) => {
    const a = s.az * DEG, p = s.pol * DEG;
    const n = new THREE.Vector3(Math.sin(p) * Math.sin(a), Math.cos(p), Math.sin(p) * Math.cos(a));
    const up = new THREE.Vector3(0, 1, 0);
    const dir = Array.isArray(s.dir) ? new THREE.Vector3(...s.dir).normalize() : up.clone().lerp(n, s.dir ?? 0.5).normalize();
    const base = new THREE.Vector3(0, 1.97, 0).addScaledVector(n, 0.225);
    const m = cone(s.rad, s.len, mat, 0, 0, 0, root, 6);
    m.position.copy(base).addScaledVector(dir, s.len * 0.38);
    m.quaternion.setFromUnitVectors(up, dir);
    return m;
  };
  const sword = (parent, len, w, bladeMat, gripMat, guardMat) => {
    const g = new THREE.Group();
    box(w, len, w * 0.28, bladeMat, 0, -len / 2 - 0.2, 0, g);
    box(w * 2.2, 0.035, 0.04, guardMat, 0, -0.2, 0, g);
    cyl(0.022, 0.022, 0.2, gripMat, 0, -0.1, 0, g, 8);
    sph(0.035, guardMat, 0, 0.01, 0, 1, 1, 1, g);
    parent.add(g);
    return g;
  };

  const flags = { eyes: true, nose: true, mouth: true, brows: true, head: true };
  const hideFace = ["spartan", "vaderHelm", "ironHelm", "deadpoolMask", "spiderMask", "steveHead", "sonic"];
  if (hideFace.some(has)) flags.eyes = flags.nose = flags.mouth = flags.brows = false;
  if (has("balaclava")) flags.nose = flags.mouth = false;
  if (["blindfold", "visor", "cowl", "sunglasses"].some(has)) flags.eyes = flags.brows = false;
  if (has("jokerFace") || has("kratosFace")) flags.mouth = has("kratosFace");

  // ----- torso -----
  const mTorso = sk.torsoBare ? mSkin : mPri;
  if (blocky) {
    box(0.56, 0.76, 0.3, mTorso, 0, 1.18, 0);
  } else {
    cyl(0.27, 0.31, 0.72, mTorso, 0, 1.18, 0, root, 18);
    sph(0.33, mTorso, 0, 1.42, 0, 1.05, 0.85, 0.78);
  }
  cyl(0.325, 0.318, 0.16, mPants, 0, 0.88, 0, root, 20);
  cyl(0.333, 0.333, 0.07, mBelt, 0, 0.99, 0, root, 20);
  box(0.12, 0.09, 0.05, mAcc, 0, 0.99, 0.315);
  cyl(0.095, 0.115, 0.14, mSkin, 0, 1.7, 0, root, 12);

  // ----- cabeça -----
  if (has("steveHead")) {
    const ft = steveFaceTex();
    const faceM = ft ? new THREE.MeshStandardMaterial({ map: ft, roughness: 0.8 }) : mSkin;
    const hairM = std(0x3b2a17, { roughness: 0.9 });
    const mats = [mSkin, mSkin, hairM, mSkin, faceM, hairM];
    const hb = put(new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.48, 0.48), mats), 0, 1.95, 0);
    hb.castShadow = true;
  } else {
    const head = put(new THREE.Mesh(new THREE.SphereGeometry(1, 32, 24), mSkin), 0, HCY, 0);
    head.scale.set(HX, HY, HZ);
    sph(0.17, mSkin, 0, 1.835, 0.045, 1, 0.78, 0.95);
    sph(0.045, mSkin, -0.226, 1.92, -0.01, 0.45, 1, 0.7);
    sph(0.045, mSkin, 0.226, 1.92, -0.01, 0.45, 1, 0.7);
  }

  // ----- rosto padrão -----
  const eyeCol = sk.eye ?? 0x3d2b1f;
  if (flags.eyes) {
    for (const sx of [-1, 1]) {
      const x = sx * 0.082, y = 1.95, z = headZ(x, y);
      sph(0.038, mWhite, x, y, z - 0.012, 1, 0.8, 0.5);
      if (has("catEyes")) {
        sph(0.022, glow(0xd9b300, 0.25), x, y, z + 0.002, 1, 1, 0.5);
        box(0.007, 0.04, 0.01, mBlack, x, y, z + 0.012);
      } else {
        sph(0.021, glow(eyeCol, has("mako") ? 1.2 : 0), x, y, z + 0.002, 1, 1, 0.5);
        sph(0.011, mBlack, x, y, z + 0.01, 1, 1, 0.5);
      }
    }
  }
  if (flags.brows) {
    const strong = has("browStrong");
    const browMat = sk.hair?.style === "bald" ? mSkin : mHair;
    for (const sx of [-1, 1]) {
      const x = sx * 0.085, y = 1.995;
      const b = box(0.08, strong ? 0.026 : 0.016, 0.014, browMat, x, y, headZ(x, y) + 0.002);
      b.rotation.z = sx * (strong ? -0.32 : 0.1);
    }
  }
  if (flags.nose && !has("bigNose")) {
    rot(cone(0.027, 0.075, mSkin, 0, 1.895, headZ(0, 1.895) + 0.004), Math.PI / 2, 0, 0);
  }
  if (has("bigNose")) sph(0.05, std(0xf0a890), 0, 1.9, headZ(0, 1.9) + 0.02);
  if (flags.mouth) {
    const y = 1.838;
    const m = box(0.075, 0.014, 0.012, mLip, 0, y, headZ(0, y) + 0.002);
    if (has("bigSmile")) {
      m.visible = false;
      decal([[-0.1, 1.865], [-0.06, 1.835], [0, 1.825], [0.06, 1.835], [0.1, 1.865]], 0.008, mLip);
      box(0.12, 0.018, 0.01, mWhite, 0, 1.842, headZ(0, 1.842) - 0.001);
    }
  }

  // ----- cabelo -----
  const hs = sk.hair?.style ?? "none";
  if (hs !== "none" && hs !== "bald") {
    if (!has("steveHead")) {
      shell(0, 66 * DEG, 0.022, mHair);
      sph(0.24, mHair, 0, 1.93, -0.065, 1, 0.95, 0.8);
    }
    if (hs === "long") {
      sph(0.2, mHair, 0, 1.72, -0.15, 1, 1.9, 0.55);
      sph(0.05, mHair, -0.21, 1.9, 0.0, 0.7, 1.7, 1);
      sph(0.05, mHair, 0.21, 1.9, 0.0, 0.7, 1.7, 1);
    } else if (hs === "slick") {
      sph(0.19, mHair, 0, 1.78, -0.15, 1, 1.0, 0.5);
    }
    (sk.hair.spikes || []).forEach((s) => spike(s, mHair));
  }
  if (has("steveHead")) box(0.5, 0.07, 0.5, std(0x3b2a17), 0, 2.2, 0);
  if (has("bangs")) {
    for (const sx of [-1, 1]) {
      const b = cone(0.032, 0.2, mHair, sx * 0.165, 1.9, headZ(sx * 0.165, 1.9) + 0.02, root, 6);
      b.rotation.set(Math.PI - 0.05, 0, sx * 0.12);
    }
  }

  // ----- peças de cabeça / rosto por tag -----
  if (has("helmet") || has("helmetBlack")) {
    const hm = has("helmetBlack") ? mGear : std(sk.primary, { roughness: 0.6 });
    shell(0, 68 * DEG, 0.032, hm);
    ring(2.02, 0.016, mGear, 0.03);
    box(0.05, 0.14, 0.05, hm, -0.255, 1.93, 0.0);
    box(0.05, 0.14, 0.05, hm, 0.255, 1.93, 0.0);
    if (has("helmetBlack")) {
      box(0.09, 0.07, 0.07, mBlack, 0, 2.13, 0.22);
      cyl(0.03, 0.03, 0.06, glow(0x66ff99, 0.6), 0, 2.13, 0.265, root, 8);
      root.children[root.children.length - 1].rotation.x = Math.PI / 2;
    }
  }
  if (has("helmetSlim")) shell(0, 64 * DEG, 0.03, mGear);
  if (has("visor")) band(1.955, 0.11, 0.022, glow(sk.accent, 0.9, { transparent: true, opacity: 0.85 }));
  if (has("neonTrim")) {
    const gl = glow(sk.accent, 1.0);
    for (const sx of [-1, 1]) {
      box(0.018, 0.55, 0.02, gl, sx * 0.17, 1.2, 0.295);
    }
    box(0.3, 0.018, 0.02, gl, 0, 1.0, 0.32);
  }
  if (has("balaclava")) {
    shell(100 * DEG, 80 * DEG, 0.012, mGear);
  }
  if (has("cap")) {
    shell(0, 66 * DEG, 0.03, mPri);
    const brim = box(0.34, 0.022, 0.2, mPri, 0, 2.02, 0.24);
    brim.rotation.x = 0.18;
    sph(0.025, mAcc, 0, 2.12, 0.18);
  }
  if (has("hoodie")) {
    sph(0.22, mPri, 0, 1.68, -0.13, 1.25, 0.7, 0.75);
    cyl(0.012, 0.012, 0.16, mWhite, -0.07, 1.5, 0.3, root, 6);
    cyl(0.012, 0.012, 0.16, mWhite, 0.07, 1.5, 0.3, root, 6);
    box(0.28, 0.2, 0.02, mSec, 0, 1.05, 0.31);
  }
  if (has("shemagh")) {
    shell(0, 74 * DEG, 0.034, mPri);
    shell(104 * DEG, 76 * DEG, 0.03, mPri, Math.PI / 2 + 0.85, Math.PI * 2 - 1.7);
    const t = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.065, 8, 20), mPri);
    t.rotation.x = Math.PI / 2; t.position.set(0, 1.72, 0.02); root.add(t);
  }
  if (has("goggles")) {
    const lens = std(0x222222, { roughness: 0.1, metalness: 0.7 });
    box(0.36, 0.035, 0.02, mGear, 0, 2.07, headZ(0, 2.07) + 0.03);
    for (const sx of [-1, 1]) cyl(0.055, 0.055, 0.03, lens, sx * 0.085, 2.075, headZ(sx * 0.085, 2.075) + 0.04, root, 12).rotation.x = Math.PI / 2;
  }
  if (has("furhood")) {
    const fur = std(0xf4f4f4, { roughness: 1 });
    shell(0, 112 * DEG, 0.05, mPri, Math.PI / 2 + 0.75, Math.PI * 2 - 1.5);
    const t = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.045, 8, 24), fur);
    t.position.set(0, 1.93, 0.115); t.scale.set(1, 1.15, 1); root.add(t);
  }
  if (has("headband")) {
    const bm = std(sk.headband ?? 0x1b2a6b, { roughness: 0.7 });
    ring(2.0, 0.024, bm, 0.004);
    box(0.17, 0.075, 0.016, std(0xc7ced6, { roughness: 0.25, metalness: 0.85 }), 0, 2.0, headZ(0, 2.0) + 0.028);
    box(0.06, 0.012, 0.018, mBlack, 0, 2.0, headZ(0, 2.0) + 0.03);
    box(0.012, 0.06, 0.018, mBlack, 0, 2.0, headZ(0, 2.0) + 0.031);
  }
  if (has("whiskers")) {
    for (const sx of [-1, 1]) for (let k = -1; k <= 1; k++) {
      const x = sx * 0.145, y = 1.89 + k * 0.022;
      const w = box(0.06, 0.006, 0.01, std(0x4a2a12), x, y, headZ(x, y) + 0.003);
      w.rotation.set(0, sx * -0.9, k * 0.18 * sx);
    }
  }
  if (has("blindfold")) band(1.955, 0.1, 0.012, mBlack);
  if (has("scarLuffy")) {
    decal([[-0.1, 1.9], [-0.095, 1.875]], 0.006, std(0x6b1d1d));
    decal([[-0.115, 1.89], [-0.075, 1.885]], 0.006, std(0x6b1d1d));
  }
  if (has("strawhat")) {
    const straw = std(0xe8c35a, { roughness: 0.95 });
    cyl(0.4, 0.42, 0.028, straw, 0, 2.1, 0, root, 28);
    shell(0, 54 * DEG, 0.038, straw);
    ring(2.06, 0.02, std(0xc1121f), 0.04);
    cyl(0.38, 0.4, 0.012, std(0xd4a93e, { roughness: 1 }), 0, 2.086, 0, root, 28);
  }
  if (has("scarForehead")) {
    decal([[-0.08, 2.05], [-0.06, 2.015], [-0.045, 1.995]], 0.01, std(0x8a1c1c));
  }
  if (has("earrings")) {
    for (const sx of [-1, 1]) {
      const e = box(0.028, 0.07, 0.01, std(0xf2f2f2), sx * 0.238, 1.86, 0.0);
      e.rotation.y = Math.PI / 2;
      box(0.012, 0.04, 0.012, std(0xd62828), sx * 0.24, 1.86, 0.0);
    }
  }
  if (has("kratosFace")) {
    const red = std(0xb00020, { roughness: 0.6 });
    decal([[-0.065, 2.07], [-0.075, 2.0], [-0.075, 1.95], [-0.07, 1.89], [-0.06, 1.83]], 0.014, red);
    sph(0.13, std(0x2a2a2a, { roughness: 1 }), 0, 1.79, 0.1, 1, 0.65, 0.8);
    box(0.06, 0.01, 0.012, mLip, 0, 1.846, headZ(0, 1.846) + 0.004);
  }
  if (has("stubble")) {
    shell(100 * DEG, 62 * DEG, 0.004, std(0x2a2018, { transparent: true, opacity: 0.55, roughness: 1 }), Math.PI / 2 - 1.1, 2.2);
  }
  if (has("scarEye")) {
    decal([[0.07, 2.02], [0.085, 1.96], [0.09, 1.9]], 0.007, std(0x9a4a4a));
  }
  if (has("pointyEars")) {
    for (const sx of [-1, 1]) {
      const e = cone(0.03, 0.15, mSkin, sx * 0.25, 1.95, -0.01);
      e.rotation.z = -sx * (Math.PI / 2 - 0.35);
    }
  }
  if (has("linkCap")) {
    shell(0, 78 * DEG, 0.034, mPri);
    const tail = cone(0.16, 0.55, mPri, 0, 2.05, -0.3);
    tail.rotation.x = -1.15;
    sph(0.04, mAcc, 0, 2.0, -0.55);
  }
  if (has("marioCap")) {
    shell(0, 76 * DEG, 0.032, mPri);
    const brim = box(0.3, 0.026, 0.18, mPri, 0, 2.02, 0.25);
    brim.rotation.x = 0.16;
    const lt = logoTex("M", 0xffffff, 0xe63946);
    const emb = cyl(0.05, 0.05, 0.012, lt ? std(0xffffff, { map: lt }) : mWhite, 0, 2.11, headZ(0, 2.11) + 0.04, root, 16);
    emb.rotation.x = Math.PI / 2 - 0.45;
  }
  if (has("mustache")) {
    const mm = std(0x2a1a10, { roughness: 1 });
    for (const sx of [-1, 1]) {
      const m = sph(0.045, mm, sx * 0.04, 1.868, headZ(sx * 0.04, 1.868) + 0.012, 1.5, 0.6, 0.7);
      m.rotation.z = sx * -0.35;
    }
  }
  if (has("assassinHood")) {
    const hood = std(sk.primary, { roughness: 0.85, side: THREE.DoubleSide });
    shell(0, 112 * DEG, 0.052, hood, Math.PI / 2 + 0.72, Math.PI * 2 - 1.44);
    const pt = cone(0.13, 0.26, hood, 0, 2.05, -0.27);
    pt.rotation.x = -1.2;
    const t = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.06, 8, 20), hood);
    t.rotation.x = Math.PI / 2; t.position.set(0, 1.7, 0); root.add(t);
  }
  if (has("cowl")) {
    const cm = std(0x121212, { roughness: 0.6 });
    shell(0, 99 * DEG, 0.03, cm);
    for (const sx of [-1, 1]) {
      cone(0.05, 0.2, cm, sx * 0.1, 2.22, -0.02, root, 6);
      const slit = glow(0xffffff, 0.9);
      const x = sx * 0.082;
      const s = box(0.08, 0.026, 0.012, slit, x, 1.955, headZ(x, 1.955) + 0.032);
      s.rotation.z = sx * 0.28;
    }
  }
  if (has("ironHelm")) {
    const red = std(sk.primary, { roughness: 0.25, metalness: 0.8 });
    const gold = std(0xc99a2e, { roughness: 0.22, metalness: 0.9 });
    shell(0, 180 * DEG, 0.03, red);
    shell(66 * DEG, 100 * DEG, 0.048, gold, Math.PI / 2 - 0.6, 1.2);
    for (const sx of [-1, 1]) {
      const x = sx * 0.078;
      const e = box(0.07, 0.02, 0.014, glow(0xdff8ff, 1.4), x, 1.955, headZ(x, 1.955) + 0.052);
      e.rotation.z = sx * -0.15;
    }
    box(0.1, 0.012, 0.012, mBlack, 0, 1.83, headZ(0, 1.83) + 0.052);
  }
  if (has("spartan")) {
    const gm = std(sk.primary, { roughness: 0.4, metalness: 0.6 });
    shell(0, 180 * DEG, 0.034, gm);
    shell(70 * DEG, 40 * DEG, 0.05, std(0xd9a521, { roughness: 0.08, metalness: 0.9, emissive: 0x6b4a00, emissiveIntensity: 0.25 }), Math.PI / 2 - 0.9, 1.8);
    box(0.07, 0.09, 0.34, gm, 0, 2.2, 0);
    for (const sx of [-1, 1]) box(0.05, 0.16, 0.12, mGear, sx * 0.25, 1.88, 0.02);
    box(0.14, 0.1, 0.05, mGear, 0, 1.82, 0.235);
  }
  if (has("vaderHelm")) {
    const hb = std(0x0c0c0c, { roughness: 0.15, metalness: 0.6 });
    shell(0, 180 * DEG, 0.04, hb);
    cone(0.12, 0.1, hb, 0, 2.2, -0.03, root, 20).scale.set(1.5, 1, 1.4);
    for (const sx of [-1, 1]) {
      const x = sx * 0.08;
      sph(0.05, std(0x050505, { roughness: 0.05, metalness: 0.9 }), x, 1.95, headZ(x, 1.95) + 0.045, 1.1, 0.8, 0.4);
    }
    box(0.22, 0.03, 0.05, hb, 0, 1.995, headZ(0, 1.995) + 0.07).rotation.x = 0.2;
    rot(cone(0.03, 0.08, hb, 0, 1.9, headZ(0, 1.9) + 0.06), Math.PI / 2, 0, 0);
    box(0.13, 0.09, 0.04, std(0x8a8f96, { roughness: 0.3, metalness: 0.8 }), 0, 1.83, headZ(0, 1.83) + 0.058);
    for (let k = -2; k <= 2; k++) box(0.008, 0.07, 0.008, mBlack, k * 0.025, 1.83, headZ(0, 1.83) + 0.082);
    cyl(0.2, 0.28, 0.09, hb, 0, 1.73, 0, root, 20);
  }
  if (has("deadpoolMask") || has("spiderMask")) {
    const mm = std(sk.primary, { roughness: 0.6 });
    if (has("spiderMask") && mPri.map) mm.map = mPri.map;
    shell(0, 180 * DEG, 0.012, mm);
    const dead = has("deadpoolMask");
    for (const sx of [-1, 1]) {
      const x = sx * 0.088;
      const patch = sph(dead ? 0.058 : 0.068, dead ? mBlack : mBlack, x, 1.955, headZ(x, 1.955) + 0.012, 1, 1.45, 0.25);
      patch.rotation.z = sx * (dead ? 0.55 : 0.4);
      const lens = sph(dead ? 0.038 : 0.054, mWhite, x, 1.955, headZ(x, 1.955) + 0.026, 1, dead ? 1.3 : 1.45, 0.25);
      lens.rotation.z = patch.rotation.z;
    }
  }
  if (has("sunglasses")) {
    const lens = std(0x050505, { roughness: 0.05, metalness: 0.95 });
    for (const sx of [-1, 1]) sph(0.046, lens, sx * 0.082, 1.95, headZ(sx * 0.082, 1.95) + 0.012, 1.45, 0.85, 0.35);
    box(0.045, 0.012, 0.012, lens, 0, 1.955, headZ(0, 1.955) + 0.012);
    for (const sx of [-1, 1]) box(0.012, 0.012, 0.12, lens, sx * 0.17, 1.955, 0.14);
  }
  if (has("jokerFace")) {
    const red = std(0xb3121f, { roughness: 0.5 });
    decal([[-0.13, 1.905], [-0.105, 1.862], [-0.055, 1.832], [0, 1.825], [0.055, 1.832], [0.105, 1.862], [0.13, 1.905]], 0.012, red);
    decal([[-0.13, 1.905], [-0.15, 1.94]], 0.01, red);
    decal([[0.13, 1.905], [0.15, 1.94]], 0.01, red);
    for (const sx of [-1, 1]) sph(0.05, mBlack, sx * 0.082, 1.95, headZ(sx * 0.082, 1.95) - 0.004, 1.3, 1.1, 0.3);
  }
  if (has("sonic")) {
    const beige = std(0xf0cfa0, { roughness: 0.6 });
    const blue = mSkin;
    sph(0.12, beige, 0, 1.87, 0.12, 1.05, 0.85, 0.9);
    for (const sx of [-1, 1]) {
      const x = sx * 0.072;
      sph(0.062, mWhite, x, 1.975, headZ(x, 1.975) - 0.004, 1, 1.25, 0.45);
      sph(0.03, std(0x1d6b2a), x + sx * 0.008, 1.975, headZ(x, 1.975) + 0.022, 1, 1.25, 0.5);
      sph(0.014, mBlack, x + sx * 0.008, 1.975, headZ(x, 1.975) + 0.036, 1, 1.2, 0.5);
    }
    sph(0.03, mBlack, 0, 1.9, headZ(0, 1.9) + 0.085);
    decal([[-0.05, 1.835], [0, 1.82], [0.05, 1.835]], 0.006, mBlack);
    const dirs = [[0, -0.15, -1], [-0.45, 0.1, -1], [0.45, 0.1, -1], [-0.7, 0.35, -0.8], [0.7, 0.35, -0.8]];
    dirs.forEach(([dx, dy, dz], i) => {
      const len = 0.42 - (i > 2 ? 0.1 : 0);
      const c = cone(0.085, len, blue, 0, 0, 0, root, 8);
      const d = new THREE.Vector3(dx, dy, dz).normalize();
      c.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d);
      c.position.set(dx * 0.14, 1.99 + dy * 0.1, -0.12).addScaledVector(d, len * 0.38);
    });
    for (const sx of [-1, 1]) cone(0.04, 0.14, blue, sx * 0.1, 2.2, 0.04, root, 6);
    sph(0.2, beige, 0, 1.25, 0.25, 1, 1.35, 0.3);
  }
  if (has("pikachu")) {
    const dark = std(0x1a1a1a);
    for (const sx of [-1, 1]) {
      const e = cone(0.06, 0.3, mSkin, sx * 0.13, 2.28, -0.03, root, 8);
      e.rotation.z = -sx * 0.4;
      const tip = cone(0.045, 0.11, dark, sx * (0.13 + 0.092), 2.4, -0.03, root, 8);
      tip.rotation.z = -sx * 0.4;
      sph(0.045, std(0xd90429, { roughness: 0.5 }), sx * 0.155, 1.86, headZ(sx * 0.155, 1.86) - 0.005, 1, 1, 0.35);
    }
    rot(cone(0.02, 0.05, dark, 0, 1.9, headZ(0, 1.9) + 0.01), Math.PI / 2, 0, 0);
    const brown = std(0x7a4a22);
    box(0.4, 0.04, 0.02, brown, 0, 1.34, -0.3);
    box(0.4, 0.04, 0.02, brown, 0, 1.12, -0.3);
    const tail = [[0, 0.95, -0.34, 0.1], [0.03, 1.1, -0.4, -0.5], [-0.04, 1.28, -0.38, 0.5], [0.04, 1.46, -0.4, -0.5]];
    tail.forEach(([x, y, z, r], i) => {
      const b = box(0.2, 0.2, 0.035, i === 0 ? brown : mSkin, x, y, z);
      b.rotation.z = r;
    });
  }

  // ----- roupas / acessórios de corpo -----
  if (has("vest")) {
    cyl(0.335, 0.35, 0.42, mGear, 0, 1.28, 0, root, 18);
    for (const x of [-0.13, 0, 0.13]) box(0.1, 0.13, 0.05, mSec, x, 1.25, 0.34);
    box(0.08, 0.5, 0.02, mGear, -0.2, 1.5, 0.28).rotation.z = 0.2;
  }
  if (has("pack")) box(0.42, 0.5, 0.2, mGear, 0, 1.28, -0.4);
  if (has("narutoJacket")) {
    cyl(0.19, 0.23, 0.14, mGear, 0, 1.66, 0, root, 14);
    for (const sx of [-1, 1]) sph(0.14, mGear, sx * 0.4, 1.53, 0, 1.1, 0.7, 1);
    box(0.03, 0.58, 0.02, mGear, 0, 1.2, 0.3);
  }
  if (has("gokuGi")) {
    sph(0.13, std(0x1d3f9e), 0, 1.6, 0.15, 1.2, 0.7, 0.6);
    cyl(0.325, 0.335, 0.14, std(0x1d3f9e), 0, 0.99, 0, root, 18);
    box(0.03, 0.55, 0.02, mSec, 0, 1.24, 0.3);
  }
  if (has("highCollar")) cyl(0.17, 0.24, 0.2, mPri, 0, 1.68, 0, root, 14);
  if (has("ropeBelt")) {
    cyl(0.33, 0.33, 0.12, std(0x7b2cbf, { roughness: 0.9 }), 0, 0.97, 0, root, 18);
    sph(0.09, std(0x7b2cbf), 0, 0.95, -0.32, 1.4, 1, 0.7);
    for (const sx of [-1, 1]) box(0.04, 0.2, 0.03, std(0x7b2cbf), sx * 0.06, 0.8, -0.33);
  }
  if (has("saiyanArmor")) {
    const white = std(0xf4f4f4, { roughness: 0.4, metalness: 0.2 });
    const gold = std(0xe8b923, { roughness: 0.3, metalness: 0.7 });
    sph(0.34, white, 0, 1.35, 0.03, 1.06, 0.95, 0.85);
    cyl(0.325, 0.335, 0.2, white, 0, 1.0, 0, root, 18);
    for (const sx of [-1, 1]) {
      sph(0.15, gold, sx * 0.4, 1.56, 0, 1.0, 0.7, 1.05);
      box(0.17, 0.22, 0.03, white, sx * 0.14, 0.78, 0.31);
      box(0.17, 0.22, 0.03, white, sx * 0.14, 0.78, -0.31);
    }
    box(0.34, 0.03, 0.03, gold, 0, 1.5, 0.3);
  }
  if (has("haori")) {
    const hm = std(0xffffff, { roughness: 0.85, map: checkerTex(0x1b6b3a, 0x111111) });
    cyl(0.34, 0.43, 0.88, hm, 0, 1.02, 0, root, 22, true, 0.35, Math.PI * 2 - 0.7);
    cyl(0.325, 0.34, 0.16, std(0xf2f2f2), 0, 0.99, 0, root, 18);
    box(0.05, 0.06, 0.62, mBlack, 0.4, 0.95, 0.1).rotation.x = 0.3;
  }
  if (has("openVest")) {
    for (const sx of [-1, 1]) {
      const v = box(0.13, 0.52, 0.04, mPri, sx * 0.19, 1.26, 0.275);
      v.rotation.z = sx * 0.06;
      sph(0.13, mPri, sx * 0.34, 1.52, 0, 1, 0.7, 1);
    }
    cyl(0.33, 0.33, 0.09, std(0xf2d03b, { roughness: 0.8 }), 0, 0.99, 0, root, 18);
  }
  if (has("leatherStraps")) {
    box(0.1, 1.0, 0.03, mGear, 0, 1.3, 0.3).rotation.z = 0.7;
    sph(0.04, std(0xb8860b, { metalness: 0.8, roughness: 0.3 }), 0, 1.32, 0.33);
    cyl(0.325, 0.335, 0.12, mGear, 0, 1.0, 0, root, 18);
    for (const sx of [-1, 1]) sph(0.13, mGear, sx * 0.4, 1.55, 0, 1.2, 0.5, 1.1);
  }
  if (has("loincloth")) {
    box(0.26, 0.34, 0.03, mGear, 0, 0.74, 0.32);
    box(0.26, 0.34, 0.03, mGear, 0, 0.74, -0.32);
  }
  if (has("tunic")) {
    cyl(0.33, 0.43, 0.34, mPri, 0, 0.78, 0, root, 20, true);
    cyl(0.318, 0.325, 0.06, mGear, 0, 0.97, 0, root, 18);
    box(0.34, 0.05, 0.04, mAcc, 0, 1.3, 0.3).rotation.z = 0.0;
  }
  if (has("overalls")) {
    cyl(0.312, 0.318, 0.48, mPants, 0, 1.03, 0, root, 18);
    box(0.3, 0.3, 0.03, mPants, 0, 1.25, 0.285);
    for (const sx of [-1, 1]) {
      box(0.06, 0.34, 0.03, mPants, sx * 0.13, 1.52, 0.255).rotation.x = -0.35;
      sph(0.03, mAcc, sx * 0.13, 1.32, 0.31);
    }
  }
  if (has("suitJacket")) {
    cyl(0.325, 0.42, 0.34, mPri, 0, 0.78, 0, root, 20, true, 0.4, Math.PI * 2 - 0.8);
    for (const sx of [-1, 1]) box(0.07, 0.42, 0.03, std(sk.secondary, { roughness: 0.6 }), sx * 0.11, 1.35, 0.3).rotation.z = sx * -0.18;
  }
  if (has("suitShirt")) {
    box(0.15, 0.46, 0.02, mWhite, 0, 1.3, 0.3);
    box(0.045, 0.4, 0.02, mBlack, 0, 1.26, 0.315);
    box(0.06, 0.05, 0.025, mBlack, 0, 1.5, 0.315);
  }
  if (has("vestSuit")) {
    box(0.17, 0.46, 0.02, mGear, 0, 1.28, 0.305);
    box(0.08, 0.06, 0.02, std(0xe8a23a), 0, 1.5, 0.315);
    box(0.1, 0.06, 0.02, std(0xf2f2f2), 0, 1.54, 0.3);
  }
  if (has("longCoat")) {
    cyl(0.33, 0.47, 0.86, mPri, 0, 0.66, 0, root, 22, true, 0.45, Math.PI * 2 - 0.9);
    cyl(0.2, 0.26, 0.1, mPri, 0, 1.64, 0, root, 14);
  }
  if (has("vaderCape") || has("cape")) {
    const col = has("cape") ? 0x121212 : 0x090909;
    const g = new THREE.BoxGeometry(0.74, 1.1, 0.03, 4, 10, 1);
    const pos = g.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const t = (0.55 - pos.getY(i)) / 1.1;
      pos.setX(i, pos.getX(i) * (1 + t * 0.35));
      pos.setZ(i, pos.getZ(i) - t * t * 0.28);
    }
    g.computeVertexNormals();
    const cm = new THREE.Mesh(g, std(col, { roughness: 0.85, side: THREE.DoubleSide }));
    cm.position.set(0, 1.1, -0.33);
    cm.castShadow = true;
    root.add(cm);
    for (const sx of [-1, 1]) sph(0.1, std(col), sx * 0.36, 1.58, -0.14, 1.3, 0.6, 1.1);
  }
  if (has("chestPanel")) {
    box(0.2, 0.15, 0.03, mGear, 0, 1.38, 0.265);
    const cols = [0xff3030, 0x4da6ff, 0xffd60a, 0x66ff66];
    cols.forEach((c, i) => box(0.026, 0.026, 0.02, glow(c, 0.8), -0.07 + i * 0.047, 1.4, 0.285));
    box(0.2, 0.05, 0.03, mGear, 0, 1.28, 0.27);
  }
  if (has("batEmblem")) {
    const em = sph(0.09, mAcc, 0, 1.42, 0.245, 1.6, 0.85, 0.2);
    for (const sx of [-1, 1]) {
      const w = box(0.1, 0.035, 0.012, mBlack, sx * 0.065, 1.425, 0.268);
      w.rotation.z = sx * 0.4;
    }
    box(0.03, 0.06, 0.012, mBlack, 0, 1.43, 0.27);
  }
  if (has("utilityBelt")) {
    for (let i = -2; i <= 2; i++) box(0.06, 0.075, 0.05, mAcc, i * 0.11, 0.99, 0.32 - Math.abs(i) * 0.035).rotation.y = i * 0.35;
  }
  if (has("arcReactor")) {
    const g = std(0xc99a2e, { metalness: 0.85, roughness: 0.25 });
    const gl = glow(0x9ff3ff, 2.0);
    rot(cyl(0.055, 0.055, 0.02, gl, 0, 1.4, 0.262, root, 20), Math.PI / 2, 0, 0);
    const t = new THREE.Mesh(new THREE.TorusGeometry(0.065, 0.015, 8, 24), g);
    t.position.set(0, 1.4, 0.262); root.add(t);
  }
  if (has("ironArmor")) {
    const gold = std(0xc99a2e, { roughness: 0.25, metalness: 0.9 });
    cyl(0.335, 0.34, 0.12, gold, 0, 0.99, 0, root, 18);
    box(0.28, 0.06, 0.03, gold, 0, 1.12, 0.3);
    for (const sx of [-1, 1]) sph(0.14, gold, sx * 0.4, 1.55, 0, 1.1, 0.65, 1.1);
  }
  if (has("pauldron")) {
    sph(0.2, mGear, -0.4, 1.56, 0, 1.2, 0.75, 1.2);
    box(0.06, 0.6, 0.02, mGear, 0.0, 1.4, 0.3).rotation.z = -0.5;
    cyl(0.32, 0.32, 0.12, std(0x5a3a1a), 0, 0.99, 0, root, 18);
  }
  if (has("studStrap")) {
    box(0.07, 0.95, 0.03, mGear, 0, 1.3, 0.3).rotation.z = -0.6;
    for (let i = 0; i < 5; i++) {
      const t = (i - 2) * 0.15;
      sph(0.016, std(0xcfd6dd, { metalness: 0.9, roughness: 0.2 }), -t * 0.58, 1.3 + t * 0.8, 0.32);
    }
    for (const sx of [-1, 1]) sph(0.14, mGear, sx * 0.4, 1.55, 0, 1.15, 0.6, 1.1);
    cyl(0.322, 0.33, 0.1, std(0x3a2a1c), 0, 0.99, 0, root, 18);
  }
  if (has("robeSkirt")) {
    cyl(0.33, 0.46, 0.6, mPri, 0, 0.68, 0, root, 22, true, 0.4, Math.PI * 2 - 0.8);
  }
  if (has("sashTail")) {
    box(0.1, 0.55, 0.02, std(0xc1121f), 0.12, 0.72, 0.33);
    box(0.1, 0.4, 0.02, std(0xc1121f), 0.2, 0.62, 0.3).rotation.z = 0.1;
    box(0.36, 0.05, 0.04, mSec, 0, 1.3, 0.29).rotation.z = 0.45;
  }
  if (has("beltPouches")) {
    for (const sx of [-1, 1]) box(0.09, 0.1, 0.07, mGear, sx * 0.2, 0.99, 0.3);
    box(0.08, 0.7, 0.03, mGear, 0, 1.3, 0.3).rotation.z = 0.7;
    box(0.08, 0.7, 0.03, mGear, 0, 1.3, 0.3).rotation.z = -0.7;
  }
  if (has("spiderEmblem")) {
    const em = new THREE.Group();
    sph(0.028, mBlack, 0, 0, 0, 1, 1.5, 0.5, em);
    sph(0.018, mBlack, 0, 0.05, 0, 1, 1, 0.5, em);
    for (let i = 0; i < 4; i++) for (const sx of [-1, 1]) {
      const l = box(0.1, 0.01, 0.01, mBlack, sx * 0.06, -0.015 + (i - 1.5) * 0.02, 0, em);
      l.rotation.z = sx * (0.5 - i * 0.28);
    }
    em.position.set(0, 1.4, 0.262);
    root.add(em);
  }
  // espadas nas costas
  const steel = std(0xcfd6dd, { roughness: 0.2, metalness: 0.9 });
  if (has("swordBack")) {
    const swordGrip = std(0x2a1d12);
    const s = sword(root, has("link") || sk.name === "Link" ? 0.7 : 0.95, 0.055, steel, swordGrip, std(0xb8860b, { metalness: 0.8, roughness: 0.3 }));
    s.position.set(0.2, 1.78, -0.36);
    s.rotation.z = -0.55;
  }
  if (has("busterSword")) {
    const s = sword(root, 1.2, 0.22, std(0xb9c2cc, { roughness: 0.3, metalness: 0.85 }), std(0x2a1d12), std(0x4a4a52, { metalness: 0.7 }));
    s.position.set(0.12, 1.85, -0.38);
    s.rotation.z = -0.5;
  }
  if (has("katanas")) {
    for (const sg of [-1, 1]) {
      const s = sword(root, 0.9, 0.04, steel, mBlack, mBlack);
      s.position.set(sg * 0.2, 1.78, -0.38);
      s.rotation.z = -sg * 0.6;
    }
  }

  // ----- braços (2 segmentos) -----
  const L1 = 0.38, L2 = 0.36;
  const sleeves = sk.sleeves ?? "long";
  const mUp = sleeves === "none" ? mSkin : mPri;
  const mFore = sleeves === "long" ? mPri : mSkin;
  const arms = [];
  for (const side of [-1, 1]) {
    const shoulder = new THREE.Group();
    shoulder.position.set(side * 0.4, 1.5, 0);
    root.add(shoulder);
    sph(0.125, mUp, 0, 0, 0, 1, 1, 1, shoulder);
    tube(0.095, 0.085, L1, mUp, 0, -L1 / 2, 0, shoulder);
    const elbow = new THREE.Group();
    elbow.position.y = -L1;
    shoulder.add(elbow);
    sph(0.088, sleeves === "long" ? mPri : mSkin, 0, 0, 0, 1, 1, 1, elbow);
    tube(0.083, 0.07, L2, mFore, 0, -L2 / 2, 0, elbow);
    sph(0.075, mGlove, 0, -L2 - 0.005, 0, 1, 1.05, 1, elbow);
    if (has("gauntlets") || sk.wrist != null) {
      const wm = sk.wrist != null ? std(sk.wrist, { roughness: 0.5 }) : mGear;
      tube(0.092, 0.088, 0.14, wm, 0, -L2 + 0.1, 0, elbow);
    }
    if (has("gauntlets")) box(0.015, 0.13, 0.07, mGear, side * 0.1, -L2 + 0.15, 0, elbow);
    if (has("bracers")) tube(0.09, 0.085, 0.2, mGear, 0, -L2 + 0.14, 0, elbow);
    arms.push({
      side, shoulder, elbow, L1, L2,
      hint: new THREE.Vector3(side * 0.55, -1, -0.28).normalize()
    });
  }

  // ----- pernas -----
  const legs = [];
  const shin = (sk.legs === "shorts") ? mSkin : mPants;
  for (const side of [-1, 1]) {
    const hip = new THREE.Group();
    hip.position.set(side * 0.16, 0.9, 0);
    root.add(hip);
    tube(0.125, 0.105, 0.42, mPants, 0, -0.21, 0, hip);
    sph(0.105, shin, 0, -0.42, 0.01, 1, 1, 1, hip);
    tube(0.1, 0.082, 0.34, shin, 0, -0.58, 0, hip);
    const bootH = has("steveHead") ? 0.12 : 0.2;
    box(0.2, bootH, 0.34, mBoots, 0, -0.9 + bootH / 2 + 0.0, 0.05, hip);
    if (!blocky) cyl(0.1, 0.095, 0.22, mBoots, 0, -0.69, 0, hip, 12);
    if (has("sonic")) cyl(0.105, 0.105, 0.05, mWhite, 0, -0.62, 0, hip, 12);
    if (has("kratosFace")) sph(0.07, mGear, 0, -0.42, 0.1, 1, 1, 0.6, hip);
    legs.push(hip);
  }

  // marcadores de equipe (só aparecem em modos de time): faixas nos braços e nas costas
  const tc = opts.teamColor ?? 0xffffff;
  const teamMat = std(tc, { emissive: tc, emissiveIntensity: 0.35, roughness: 0.5 });
  const teamBands = [];
  for (const arm of arms) {
    const t = new THREE.Mesh(new THREE.TorusGeometry(0.105, 0.035, 8, 20), teamMat);
    t.rotation.x = Math.PI / 2;
    t.position.set(0, -0.17, 0);
    arm.shoulder.add(t);
    teamBands.push(t);
  }
  const backBand = box(0.3, 0.07, 0.02, teamMat, 0, 1.62, -0.3);
  teamBands.push(backBand);
  teamBands.forEach((m) => { m.visible = !!opts.team; });

  root.traverse((o) => { if (o.isMesh) o.castShadow = true; });
  return { root, arms, legs, teamMat, teamBands };
}

// ========== BRAÇO: IK de 2 ossos ==========
const _d = new THREE.Vector3(), _s = new THREE.Vector3(), _u = new THREE.Vector3(), _e = new THREE.Vector3(), _f = new THREE.Vector3();
const _q = new THREE.Quaternion(), _qi = new THREE.Quaternion();
const DOWN = new THREE.Vector3(0, -1, 0);

export function solveArm(arm, target) {
  const S = arm.shoulder.position;
  _d.copy(target).sub(S);
  let dist = _d.length();
  const max = arm.L1 + arm.L2 - 0.003;
  dist = Math.min(Math.max(dist, 0.15), max);
  _d.normalize();
  const cosA = THREE.MathUtils.clamp((arm.L1 * arm.L1 + dist * dist - arm.L2 * arm.L2) / (2 * arm.L1 * dist), -1, 1);
  const A = Math.acos(cosA);
  _s.copy(arm.hint).addScaledVector(_d, -arm.hint.dot(_d));
  if (_s.lengthSq() < 1e-6) _s.set(arm.side, 0, 0);
  _s.normalize();
  _u.copy(_d).multiplyScalar(cosA).addScaledVector(_s, Math.sin(A));
  _e.copy(S).addScaledVector(_u, arm.L1);
  _f.copy(S).addScaledVector(_d, dist).sub(_e).normalize();
  arm.shoulder.quaternion.setFromUnitVectors(DOWN, _u);
  _q.setFromUnitVectors(DOWN, _f);
  _qi.copy(arm.shoulder.quaternion).invert();
  arm.elbow.quaternion.copy(_qi).multiply(_q);
}

// Como cada arma é segurada (coordenadas locais do modelo; "hand" = posição da mão direita no espaço da mira)
export const WEAPON_HOLD = {
  faca: { grip: [0, 0, 0.02], support: null, hand: [0.2, -0.26, 0.3] },
  pistola: { grip: [0, -0.16, 0.02], support: [-0.015, -0.2, 0.08], hand: [0.1, -0.2, 0.3] },
  espingarda: { grip: [0, -0.14, 0.15], support: [0, -0.06, 0.38], hand: [0.1, -0.2, 0.3] },
  rifle: { grip: [0, -0.18, 0.25], support: [0, -0.08, 0.45], hand: [0.1, -0.2, 0.3] },
  sniper: { grip: [0, -0.16, 0.22], support: [0, -0.08, 0.45], hand: [0.1, -0.2, 0.3] }
};
export const AIM_ORIGIN_Y = 1.45;

// ========== SKINS DE ARMAS ==========
export const WEAPON_SKINS = {
  padrao: { name: "Padrão", metal: 0x9aa5b0, dark: 0x2c3238, wood: 0x8b5a2b, accent: 0x546e7a },
  ouro: { name: "Ouro", metal: 0xf0c14a, dark: 0x8a6a1e, wood: 0xb8860b, accent: 0xffe082, shine: true, fx: "gold" },
  carbono: { name: "Carbono", metal: 0x2a2e33, dark: 0x111315, wood: 0x1b1f24, accent: 0x00e5ff, tex: "carbon" },
  camo: { name: "Camuflado", metal: 0x556b2f, dark: 0x2f3b1c, wood: 0x6b4f2a, accent: 0x8fbc8f, tex: "camo" },
  rosa: { name: "Rosa Neon", metal: 0xff6bcb, dark: 0x4a1f3a, wood: 0x8b3a62, accent: 0xffb6e6, glow: 0.35 },
  gelo: { name: "Gelo", metal: 0xb8e0ff, dark: 0x3a5568, wood: 0x6a8fa8, accent: 0xe0f7ff, fx: "ice", shine: true },
  rasengan: { name: "Rasengan", metal: 0x4cc9f0, dark: 0x1d3557, wood: 0x457b9d, accent: 0x90e0ef, fx: "rasengan", glow: 0.25 },
  kamehameha: { name: "Kamehameha", metal: 0x4ea8de, dark: 0x023e8a, wood: 0x0077b6, accent: 0x90e0ef, fx: "kame", glow: 0.25 },
  haki: { name: "Haki", metal: 0x2b2d42, dark: 0x000000, wood: 0x4a4e69, accent: 0xef233c, fx: "haki", glow: 0.3 },
  void: { name: "Vazio", metal: 0xe0e0e0, dark: 0x111111, wood: 0x424242, accent: 0x7b2cbf, fx: "void", glow: 0.3 },
  mjolnir: { name: "Mjölnir", metal: 0xb0bec5, dark: 0x37474f, wood: 0x6d4c41, accent: 0x4fc3f7, fx: "hammer", shine: true },
  energy: { name: "Energy Sword", metal: 0xb2ff59, dark: 0x1b5e20, wood: 0x33691e, accent: 0xccff90, fx: "energy", glow: 0.25 },
  lightsaber: { name: "Sabre de Luz", metal: 0x4cc9f0, dark: 0x1a1a1a, wood: 0x2b2b2b, accent: 0x90e0ef, fx: "saber", glow: 0.2 },
  batarang: { name: "Batarang", metal: 0x8e8e8e, dark: 0x111111, wood: 0x2b2b2b, accent: 0xffd60a, fx: "bat" },
  repulsor: { name: "Repulsor", metal: 0xb0bec5, dark: 0x263238, wood: 0x37474f, accent: 0x4fc3f7, fx: "repulsor", shine: true }
};
export const WEAPON_SKIN_IDS = Object.keys(WEAPON_SKINS);

export function makeWeaponMats(skinId) {
  const sk = WEAPON_SKINS[skinId] || WEAPON_SKINS.padrao;
  const g = sk.glow || 0;
  const mats = {
    metal: new THREE.MeshStandardMaterial({ color: sk.metal, metalness: sk.shine ? 1 : 0.85, roughness: sk.shine ? 0.15 : 0.28, emissive: g ? sk.metal : 0x000000, emissiveIntensity: g }),
    dark: new THREE.MeshStandardMaterial({ color: sk.dark, metalness: 0.4, roughness: 0.55 }),
    wood: new THREE.MeshStandardMaterial({ color: sk.wood, roughness: 0.75, metalness: 0.05 }),
    accent: new THREE.MeshStandardMaterial({ color: sk.accent, metalness: 0.6, roughness: 0.35, emissive: sk.accent, emissiveIntensity: 0.25 + g }),
    blade: new THREE.MeshStandardMaterial({ color: 0xeef3f6, metalness: 0.95, roughness: 0.12 })
  };
  if (sk.tex === "carbon") {
    const t = carbonTex();
    if (t) { mats.dark.map = t; mats.wood.map = t; mats.dark.color.set(0xffffff); mats.wood.color.set(0xffffff); }
  } else if (sk.tex === "camo") {
    const t = camoTex(0x556b2f, [0x2f3b1c, 0x8b7a45, 0x1f2a12], 11);
    if (t) { mats.dark.map = t; mats.wood.map = t; mats.dark.color.set(0xffffff); mats.wood.color.set(0xffffff); }
  }
  return mats;
}

// efeitos temáticos nas armas (cano em +Z; muzzle = posição do cano)
export function decorateWeapon(g, type, skinId, muzzlePos) {
  const sk = WEAPON_SKINS[skinId];
  if (!sk || !sk.fx) return;
  const gl = (c, i = 1.5, o = {}) => new THREE.MeshStandardMaterial({ color: c, emissive: c, emissiveIntensity: i, roughness: 0.3, ...o });
  const add = (m) => { m.castShadow = false; g.add(m); return m; };
  const mz = muzzlePos;
  const isKnife = type === "faca";
  switch (sk.fx) {
    case "rasengan":
    case "kame": {
      const r = sk.fx === "kame" ? 0.13 : 0.1;
      const o = add(new THREE.Mesh(new THREE.SphereGeometry(r, 18, 14), gl(sk.accent, 1.2, { transparent: true, opacity: 0.8 })));
      o.position.set(mz.x, mz.y, mz.z + r + 0.04);
      const c = add(new THREE.Mesh(new THREE.SphereGeometry(r * 0.55, 14, 10), gl(0xffffff, 2)));
      c.position.copy(o.position);
      if (sk.fx === "rasengan") for (let i = 0; i < 2; i++) {
        const t = add(new THREE.Mesh(new THREE.TorusGeometry(r * 1.05, 0.008, 6, 24), gl(0xffffff, 1.5)));
        t.position.copy(o.position);
        t.rotation.set(i * 1.1, i * 0.7, 0.3);
      }
      break;
    }
    case "saber": {
      const len = 0.8;
      const b = add(new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, len, 10), gl(sk.metal, 1.6, { transparent: true, opacity: 0.8 })));
      b.rotation.x = Math.PI / 2; b.position.set(mz.x, mz.y, mz.z + len / 2);
      const c = add(new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, len, 8), gl(0xffffff, 2.5)));
      c.rotation.x = Math.PI / 2; c.position.copy(b.position);
      break;
    }
    case "energy": {
      for (const sx of [-1, 1]) {
        const b = add(new THREE.Mesh(new THREE.BoxGeometry(0.022, 0.15, 0.72), gl(sk.metal, 1.4, { transparent: true, opacity: 0.85 })));
        b.position.set(mz.x + sx * 0.04, mz.y, mz.z + 0.36);
        b.rotation.z = sx * 0.06;
      }
      break;
    }
    case "hammer": {
      const h = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.15, 0.15), new THREE.MeshStandardMaterial({ color: 0x9aa5ad, metalness: 0.9, roughness: 0.25 }));
      h.position.set(0, 0.2, 0.28); add(h);
      for (const sx of [-1, 1]) { const e = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.16, 0.16), gl(sk.accent, 0.9)); e.position.set(sx * 0.105, 0.2, 0.28); add(e); }
      const l = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.012, 0.3), gl(sk.accent, 2)); l.position.set(0.07, 0.01, 0.4); add(l);
      break;
    }
    case "bat": {
      for (const sx of [-1, 1]) {
        const w = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.012, 0.11), new THREE.MeshStandardMaterial({ color: 0x1b1b1b, metalness: 0.7, roughness: 0.3 }));
        w.position.set(sx * 0.13, 0.04, 0.3); w.rotation.set(0, sx * -0.35, sx * 0.25); add(w);
        const t = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.1, 4), new THREE.MeshStandardMaterial({ color: sk.accent, emissive: sk.accent, emissiveIntensity: 0.4 }));
        t.rotation.z = -sx * Math.PI / 2; t.position.set(sx * 0.25, 0.04, 0.3); add(t);
      }
      break;
    }
    case "repulsor": {
      const d = add(new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.02, 20), gl(sk.accent, 2.2)));
      d.rotation.x = Math.PI / 2; d.position.set(mz.x, mz.y, mz.z + 0.02);
      const t = add(new THREE.Mesh(new THREE.TorusGeometry(0.09, 0.014, 8, 24), new THREE.MeshStandardMaterial({ color: 0xc99a2e, metalness: 0.9, roughness: 0.2 })));
      t.position.set(mz.x, mz.y, mz.z + 0.02);
      break;
    }
    case "haki": {
      const red = gl(0xef233c, 1.3);
      for (const sx of [-1, 1]) { const s = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.012, 0.6), red); s.position.set(sx * 0.06, 0.03, 0.4); add(s); }
      for (let i = 0; i < 4; i++) {
        const sm = new THREE.Mesh(new THREE.SphereGeometry(0.045 + i * 0.012, 8, 6), new THREE.MeshStandardMaterial({ color: 0x0a0a0a, transparent: true, opacity: 0.55, roughness: 1 }));
        sm.position.set((i % 2 ? 1 : -1) * 0.05, 0.02 + i * 0.03, mz.z + 0.05 + i * 0.07); add(sm);
      }
      break;
    }
    case "void": {
      const p = gl(0x7b2cbf, 1.6, { transparent: true, opacity: 0.85 });
      const t = add(new THREE.Mesh(new THREE.TorusGeometry(0.085, 0.012, 8, 28), p));
      t.position.set(mz.x, mz.y, mz.z + 0.04);
      for (let i = 0; i < 3; i++) {
        const a = i * 2.1;
        const s = add(new THREE.Mesh(new THREE.SphereGeometry(0.016, 8, 6), gl(0xd9a6ff, 2)));
        s.position.set(mz.x + Math.cos(a) * 0.085, mz.y + Math.sin(a) * 0.085, mz.z + 0.04);
      }
      break;
    }
    case "ice": {
      const ic = new THREE.MeshStandardMaterial({ color: 0xcdeeff, transparent: true, opacity: 0.8, roughness: 0.05, metalness: 0.1, emissive: 0x88c8ff, emissiveIntensity: 0.3 });
      [[0.0, 0.14, 0.2, 0.18], [0.04, 0.12, 0.38, 0.14], [-0.04, 0.12, 0.5, 0.12]].forEach(([x, y, z, h]) => { const c = new THREE.Mesh(new THREE.ConeGeometry(0.03, h, 5), ic); c.position.set(x, y, z); add(c); });
      break;
    }
    case "gold": {
      const e = new THREE.MeshStandardMaterial({ color: 0xfff1a8, metalness: 1, roughness: 0.1 });
      for (let i = 0; i < 3; i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.115, 0.008, 0.02), e); b.position.set(0, 0.09 + (isKnife ? 0.0 : 0), 0.2 + i * 0.1); add(b); }
      break;
    }
  }
}

// ========== POSE DOS BRAÇOS (segurando a arma ou balançando) ==========
const _eu = new THREE.Euler();
const _hand = new THREE.Vector3();
const _loc = new THREE.Vector3();

// converte ponto local da arma para o espaço do jogador (considera mira/pitch e recuo)
export function weaponAnchor(u, local, out) {
  out.copy(local).add(u.weaponMesh.position);
  _eu.copy(u.weaponHolder.rotation);
  out.applyEuler(_eu).add(u.weaponHolder.position);
  _eu.set(u.weaponPivot.rotation.x, 0, 0);
  out.applyEuler(_eu).add(u.weaponPivot.position);
  return out;
}

export function poseArms(u, swing) {
  if (!u.arms) return;
  const [armL, armR] = u.arms;
  const hold = u.weaponType && u.weaponMesh && WEAPON_HOLD[u.weaponType];
  const idle = (arm, sw) => {
    arm.shoulder.rotation.set(sw, 0, arm.side * 0.05);
    arm.elbow.rotation.set(-0.22 - Math.abs(sw) * 0.25, 0, 0);
  };
  if (!hold) {
    idle(armL, -swing * 0.8);
    idle(armR, swing * 0.8);
    return;
  }
  solveArm(armR, weaponAnchor(u, _loc.set(...hold.grip), _hand));
  if (hold.support) solveArm(armL, weaponAnchor(u, _loc.set(...hold.support), _hand));
  else idle(armL, -swing * 0.8);
}
